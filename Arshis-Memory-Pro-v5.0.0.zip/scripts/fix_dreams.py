#!/usr/bin/env python3
"""
Auto-fix script for dream/sleep data linkage

Run this script to automatically:
1. Link all unlinked dreams to sleep sessions
2. Update improvements count
3. Verify data consistency
"""

import json
import os
from datetime import datetime, timedelta


def fix_dream_linkage():
    """Fix dream linkage to sleep sessions"""
    
    dreams_path = "/root/.openclaw/data/memory-custom/dreams.json"
    sleep_path = "/root/.openclaw/data/memory-custom/sleep.json"
    
    # Load data
    dreams = []
    if os.path.exists(dreams_path):
        with open(dreams_path, 'r', encoding='utf-8') as f:
            dreams = json.load(f)
    
    sleep_data = []
    if os.path.exists(sleep_path):
        with open(sleep_path, 'r', encoding='utf-8') as f:
            sleep_data = json.load(f)
    
    if not sleep_data:
        print("[WARN] No sleep data found")
        return
    
    if not dreams:
        print("[INFO] No dreams to link")
        return
    
    # Get last night's sleep
    last_night = sleep_data[-1]
    
    # Link unlinked dreams
    linked_count = 0
    for dream in dreams:
        dream_date = dream.get('created_at', '')[:10]
        sleep_date = last_night.get('date', '')
        
        # Link if same date or dream is from last night
        if dream_date == sleep_date or not dream.get('linked_to_sleep', False):
            if 'dreams' not in last_night:
                last_night['dreams'] = []
            
            # Check if already linked
            already_linked = any(
                d.get('id') == dream['id'] 
                for d in last_night['dreams']
            )
            
            if not already_linked:
                last_night['dreams'].append({
                    "id": dream['id'],
                    "content": dream.get('content', '')[:100],
                    "linked_at": datetime.now().isoformat()
                })
                dream['linked_to_sleep'] = True
                linked_count += 1
    
    # Update improvements count
    last_night['improvements'] = len(last_night['dreams'])
    last_night['consolidated'] = len(last_night['dreams']) > 0
    
    # Save data
    with open(dreams_path, 'w', encoding='utf-8') as f:
        json.dump(dreams, f, indent=2, ensure_ascii=False)
    
    with open(sleep_path, 'w', encoding='utf-8') as f:
        json.dump(sleep_data, f, indent=2, ensure_ascii=False)
    
    print(f"[OK] Fixed dream linkage")
    print(f"  Linked dreams: {linked_count}")
    print(f"  Total improvements: {last_night['improvements']}")


if __name__ == "__main__":
    fix_dream_linkage()
