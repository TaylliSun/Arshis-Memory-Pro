#!/usr/bin/env python3
"""
Usage Statistics for Arshis-memory-pro

Tracks:
- Memory operations (store/recall/delete)
- Provider usage (which provider is used)
- Performance metrics (latency, hit rate)
- Error tracking

Output:
- Daily statistics
- Weekly summaries
- Performance reports
"""

import json
import os
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional


class UsageStats:
    """Usage Statistics Tracker"""
    
    def __init__(self, stats_path: str = "/root/.openclaw/data/memory-custom/stats.json"):
        """
        Initialize Usage Statistics
        
        Args:
            stats_path: Path to statistics file
        """
        self.stats_path = stats_path
        self.stats = self._load_stats()
    
    def _load_stats(self) -> Dict[str, Any]:
        """Load statistics from file"""
        if not os.path.exists(self.stats_path):
            return {
                "total_operations": 0,
                "operations": {
                    "store": 0,
                    "recall": 0,
                    "delete": 0,
                    "search": 0
                },
                "providers": {
                    "siliconflow": 0,
                    "dashscope": 0,
                    "jina": 0,
                    "openai": 0,
                    "cohere": 0,
                    "other": 0
                },
                "performance": {
                    "avg_latency_ms": 0,
                    "min_latency_ms": 0,
                    "max_latency_ms": 0,
                    "latency_samples": []
                },
                "errors": {
                    "total": 0,
                    "by_type": {}
                },
                "daily": {},
                "last_updated": None
            }
        
        try:
            with open(self.stats_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Failed to load stats: {e}")
            return self._load_stats()  # Return default
    
    def _save_stats(self):
        """Save statistics to file"""
        try:
            os.makedirs(os.path.dirname(self.stats_path), exist_ok=True)
            
            with open(self.stats_path, 'w', encoding='utf-8') as f:
                json.dump(self.stats, f, indent=2, ensure_ascii=False)
        
        except Exception as e:
            print(f"[WARN] Failed to save stats: {e}")
    
    def record_operation(self, operation: str, provider: str = None, latency_ms: float = None):
        """
        Record an operation
        
        Args:
            operation: Operation type (store/recall/delete/search)
            provider: Provider used (siliconflow/dashscope/etc)
            latency_ms: Operation latency in milliseconds
        """
        # Update total
        self.stats["total_operations"] += 1
        
        # Update operation count
        if operation in self.stats["operations"]:
            self.stats["operations"][operation] += 1
        else:
            self.stats["operations"][operation] = 1
        
        # Update provider count
        if provider:
            if provider in self.stats["providers"]:
                self.stats["providers"][provider] += 1
            else:
                self.stats["providers"]["other"] += 1
        
        # Update performance metrics
        if latency_ms is not None:
            samples = self.stats["performance"]["latency_samples"]
            samples.append(latency_ms)
            
            # Keep last 1000 samples
            if len(samples) > 1000:
                samples = samples[-1000:]
            
            self.stats["performance"]["latency_samples"] = samples
            self.stats["performance"]["avg_latency_ms"] = sum(samples) / len(samples)
            self.stats["performance"]["min_latency_ms"] = min(samples)
            self.stats["performance"]["max_latency_ms"] = max(samples)
        
        # Update daily stats
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in self.stats["daily"]:
            self.stats["daily"][today] = {
                "operations": 0,
                "by_operation": {}
            }
        
        self.stats["daily"][today]["operations"] += 1
        
        if operation not in self.stats["daily"][today]["by_operation"]:
            self.stats["daily"][today]["by_operation"][operation] = 0
        self.stats["daily"][today]["by_operation"][operation] += 1
        
        # Update timestamp
        self.stats["last_updated"] = datetime.now().isoformat()
        
        # Save
        self._save_stats()
    
    def record_error(self, error_type: str, provider: str = None):
        """
        Record an error
        
        Args:
            error_type: Error type (timeout/connection/api/etc)
            provider: Provider that failed
        """
        self.stats["errors"]["total"] += 1
        
        if error_type not in self.stats["errors"]["by_type"]:
            self.stats["errors"]["by_type"][error_type] = 0
        self.stats["errors"]["by_type"][error_type] += 1
        
        self._save_stats()
    
    def get_summary(self) -> Dict[str, Any]:
        """Get statistics summary"""
        return {
            "total_operations": self.stats["total_operations"],
            "operations": self.stats["operations"],
            "providers": self.stats["providers"],
            "performance": {
                "avg_latency_ms": round(self.stats["performance"]["avg_latency_ms"], 2),
                "min_latency_ms": round(self.stats["performance"]["min_latency_ms"], 2),
                "max_latency_ms": round(self.stats["performance"]["max_latency_ms"], 2)
            },
            "errors": self.stats["errors"]["total"],
            "last_updated": self.stats["last_updated"]
        }
    
    def get_daily_stats(self, days: int = 7) -> List[Dict[str, Any]]:
        """Get daily statistics for last N days"""
        daily_stats = []
        
        for i in range(days):
            date = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
            if date in self.stats["daily"]:
                daily_stats.append({
                    "date": date,
                    "operations": self.stats["daily"][date]["operations"],
                    "by_operation": self.stats["daily"][date]["by_operation"]
                })
            else:
                daily_stats.append({
                    "date": date,
                    "operations": 0,
                    "by_operation": {}
                })
        
        return daily_stats
    
    def reset(self):
        """Reset all statistics"""
        self.stats = self._load_stats()  # Load default
        self._save_stats()
        print("[INFO] Statistics reset")
    
    def print_report(self):
        """Print statistics report"""
        summary = self.get_summary()
        daily = self.get_daily_stats(7)
        
        print("\n" + "=" * 60)
        print("Arshis-memory-pro Usage Statistics")
        print("=" * 60)
        
        print(f"\nTotal Operations: {summary['total_operations']}")
        print("\nOperations Breakdown:")
        for op, count in summary["operations"].items():
            print(f"  {op}: {count}")
        
        print("\nProvider Usage:")
        for provider, count in summary["providers"].items():
            if count > 0:
                print(f"  {provider}: {count}")
        
        print("\nPerformance:")
        print(f"  Avg Latency: {summary['performance']['avg_latency_ms']} ms")
        print(f"  Min Latency: {summary['performance']['min_latency_ms']} ms")
        print(f"  Max Latency: {summary['performance']['max_latency_ms']} ms")
        
        print(f"\nErrors: {summary['errors']}")
        
        print("\nDaily Operations (Last 7 Days):")
        for day in daily:
            print(f"  {day['date']}: {day['operations']} operations")
        
        print(f"\nLast Updated: {summary['last_updated']}")
        print("\n" + "=" * 60)


def main():
    """Main function for testing"""
    
    print("Arshis-memory-pro Usage Statistics")
    print("=" * 60)
    
    # Initialize stats
    stats = UsageStats()
    
    # Record some test operations
    print("\n[TEST] Recording operations...")
    stats.record_operation("store", "siliconflow", 50.5)
    stats.record_operation("recall", "siliconflow", 30.2)
    stats.record_operation("recall", "dashscope", 45.8)
    stats.record_operation("search", "jina", 25.1)
    
    # Record an error
    stats.record_error("timeout", "openai")
    
    # Print report
    print("\n[TEST] Statistics Report:")
    stats.print_report()
    
    print("\n[OK] Usage Statistics test completed")


if __name__ == "__main__":
    main()
