#!/usr/bin/env python3
"""
Arshis-Memory-Pro Self-Evolution Engine (v2.0)

真正的自我进化：不是调参数，是改变行为策略。

能力：
1. 策略发现 — 从检索失败模式中学习新策略
2. 规则生成 — 自动生成检索路由规则
3. 策略库 — 存储所有学习到的策略
4. 策略评估 — 根据效果强化/淘汰策略
5. 策略应用 — 检索时自动应用最佳策略集

进化层级：
  Level 1: 参数调优（权重/阈值/衰减）
  Level 2: 规则学习（条件过滤/路由）
  Level 3: 策略进化（生成/淘汰/合并策略）
  Level 4: 架构反思（发现系统性问题并报告）
"""

import os
import sys
import json
import time
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional
from collections import defaultdict

# 配置路径
EVOLUTION_DIR = os.path.expanduser("~/.openclaw/data/memory-custom/evolution")
STRATEGY_DB = os.path.join(EVOLUTION_DIR, "strategies.json")
FEEDBACK_LOG = os.path.join(EVOLUTION_DIR, "feedback.jsonl")
REPORT_DIR = os.path.join(EVOLUTION_DIR, "reports")


class EvolutionConfig:
    """进化基础配置"""
    DEFAULT = {
        "version": "2.0.0",
        "created_at": None,
        "last_evolved": None,
        "evolution_level": 1,           # 当前进化层级
        "evolution_count": 0,
        
        # Level 1: 参数层
        "parameters": {
            "vector_weight": 0.7,
            "bm25_weight": 0.3,
            "min_confidence": 0.1,
        },
        
        # Level 2: 规则层
        "rules": [],
        
        # Level 3: 策略层
        "strategies": [],
        
        # 统计
        "total_feedback": 0,
        "total_corrections": 0,
        "strategy_effectiveness": {},
    }


class FeedbackCollector:
    """反馈收集器"""
    
    def __init__(self):
        os.makedirs(EVOLUTION_DIR, exist_ok=True)
    
    def record(self, query: str, results: List[Dict], used: bool = False,
               expected_category: str = None, actual_category: str = None,
               correction: str = None):
        """
        记录反馈
        
        Args:
            query: 检索查询
            results: 返回结果
            used: 是否被使用
            expected_category: 期望的分类
            actual_category: 实际的分类
            correction: 用户纠正信息
        """
        feedback = {
            "timestamp": int(time.time()),
            "query": query,
            "result_count": len(results),
            "top_score": results[0].get("score", 0) if results else 0,
            "top_category": results[0].get("category", "") if results else "",
            "used": used,
        }
        
        if expected_category:
            feedback["expected_category"] = expected_category
            feedback["actual_category"] = actual_category or feedback["top_category"]
            feedback["category_match"] = expected_category == feedback["actual_category"]
        
        if correction:
            feedback["correction"] = correction
            feedback["type"] = "correction"
        elif not used and feedback["top_score"] > 0.1:
            feedback["type"] = "miss"  # 有结果但没用
        elif not results:
            feedback["type"] = "empty"  # 没返回结果
        else:
            feedback["type"] = "hit"
        
        self._append(feedback)
        return feedback
    
    def _append(self, data: Dict):
        with open(FEEDBACK_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(data, ensure_ascii=False) + "\n")
    
    def get_recent(self, limit: int = 200) -> List[Dict]:
        if not os.path.exists(FEEDBACK_LOG):
            return []
        feedbacks = []
        with open(FEEDBACK_LOG, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        feedbacks.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return feedbacks[-limit:]


class PatternAnalyzer:
    """模式分析器 — 从反馈中发现规律"""
    
    @staticmethod
    def analyze_misclassifications(feedbacks: List[Dict]) -> List[Dict]:
        """
        分析分类错误模式
        
        发现：当查询包含某些关键词时，经常返回错误分类的结果
        """
        cat_errors = defaultdict(lambda: {"total": 0, "errors": 0, "wrong_as": defaultdict(int)})
        
        for fb in feedbacks:
            expected = fb.get("expected_category")
            actual = fb.get("actual_category") or fb.get("top_category", "")
            query = fb.get("query", "")
            
            if expected and actual:
                cat_errors[expected]["total"] += 1
                if expected != actual:
                    cat_errors[expected]["errors"] += 1
                    cat_errors[expected]["wrong_as"][actual] += 1
        
        # 找出错误率 > 30% 的模式
        patterns = []
        for expected_cat, stats in cat_errors.items():
            if stats["total"] >= 3:  # 至少 3 次
                error_rate = stats["errors"] / stats["total"]
                if error_rate > 0.3:
                    patterns.append({
                        "type": "category_misclassification",
                        "expected": expected_cat,
                        "total": stats["total"],
                        "errors": stats["errors"],
                        "error_rate": round(error_rate, 3),
                        "wrong_as": dict(stats["wrong_as"]),
                    })
        
        return patterns
    
    @staticmethod
    def analyze_empty_results(feedbacks: List[Dict]) -> List[Dict]:
        """
        分析空结果模式
        
        发现：某些类型的查询经常返回空结果
        """
        empty_patterns = defaultdict(int)
        
        for fb in feedbacks:
            if fb.get("type") == "empty" or fb.get("result_count", 0) == 0:
                query = fb.get("query", "")
                # 提取查询模式（简单的词频）
                for word in query.split():
                    if len(word) > 1:
                        empty_patterns[word] += 1
        
        patterns = []
        for word, count in empty_patterns.items():
            if count >= 2:
                patterns.append({
                    "type": "frequent_empty",
                    "keyword": word,
                    "count": count,
                })
        
        return patterns
    
    @staticmethod
    def analyze_unused_results(feedbacks: List[Dict]) -> List[Dict]:
        """
        分析未使用结果模式
        
        发现：某些查询虽然有结果，但用户从不用
        """
        unused_by_cat = defaultdict(lambda: {"total": 0, "unused": 0})
        
        for fb in feedbacks:
            if fb.get("type") in ("hit", "miss"):
                cat = fb.get("top_category", "unknown")
                unused_by_cat[cat]["total"] += 1
                if not fb.get("used"):
                    unused_by_cat[cat]["unused"] += 1
        
        patterns = []
        for cat, stats in unused_by_cat.items():
            if stats["total"] >= 3:
                unused_rate = stats["unused"] / stats["total"]
                if unused_rate > 0.5:
                    patterns.append({
                        "type": "low_utilization",
                        "category": cat,
                        "total": stats["total"],
                        "unused": stats["unused"],
                        "unused_rate": round(unused_rate, 3),
                    })
        
        return patterns


class StrategyGenerator:
    """策略生成器 — 根据模式生成进化策略"""
    
    @staticmethod
    def generate_category_filter_rule(pattern: Dict) -> Optional[Dict]:
        """
        生成分类过滤规则
        
        当发现某类查询经常返回错误分类时：
        → 生成规则：查询包含特定词时，强制过滤为正确分类
        """
        if pattern["type"] != "category_misclassification":
            return None
        
        expected = pattern["expected"]
        
        # 生成策略
        strategy = {
            "id": f"cat_filter_{expected}",
            "name": f"Category filter for '{expected}'",
            "type": "category_filter",
            "level": 2,
            "trigger": {
                "condition": "query_contains_keywords",
                "category_hint": expected,  # 如果查询暗示了某个分类
            },
            "action": {
                "type": "force_category_filter",
                "category": expected,
                "min_score_boost": 0.1,  # 给匹配的结果加分
            },
            "metadata": {
                "learned_from": pattern,
                "error_rate_before": pattern["error_rate"],
            },
            "stats": {
                "created_at": datetime.utcnow().isoformat(),
                "times_triggered": 0,
                "successes": 0,
                "failures": 0,
                "effectiveness": 0.0,
            }
        }
        
        return strategy
    
    @staticmethod
    def generate_keyword_expansion_rule(pattern: Dict) -> Optional[Dict]:
        """
        生成关键词扩展规则
        
        当发现某些词经常返回空结果时：
        → 生成规则：查询包含该词时，自动扩展到相关词
        """
        if pattern["type"] != "frequent_empty":
            return None
        
        strategy = {
            "id": f"keyword_expand_{pattern['keyword']}",
            "name": f"Keyword expansion for '{pattern['keyword']}'",
            "type": "keyword_expansion",
            "level": 2,
            "trigger": {
                "condition": "query_contains",
                "keyword": pattern["keyword"],
            },
            "action": {
                "type": "expand_query",
                "strategy": "semantic_broaden",  # 扩展查询范围
            },
            "metadata": {
                "learned_from": pattern,
                "empty_count": pattern["count"],
            },
            "stats": {
                "created_at": datetime.utcnow().isoformat(),
                "times_triggered": 0,
                "successes": 0,
                "failures": 0,
                "effectiveness": 0.0,
            }
        }
        
        return strategy
    
    @staticmethod
    def generate_category_demote_rule(pattern: Dict) -> Optional[Dict]:
        """
        生成分类降权规则
        
        当发现某分类的结果经常不被使用时：
        → 生成规则：该分类的结果默认降权
        """
        if pattern["type"] != "low_utilization":
            return None
        
        strategy = {
            "id": f"cat_demote_{pattern['category']}",
            "name": f"Category demotion for '{pattern['category']}'",
            "type": "category_demote",
            "level": 2,
            "trigger": {
                "condition": "result_category_is",
                "category": pattern["category"],
            },
            "action": {
                "type": "score_penalty",
                "penalty": 0.1,  # 降权 10%
            },
            "metadata": {
                "learned_from": pattern,
                "unused_rate_before": pattern["unused_rate"],
            },
            "stats": {
                "created_at": datetime.utcnow().isoformat(),
                "times_triggered": 0,
                "successes": 0,
                "failures": 0,
                "effectiveness": 0.0,
            }
        }
        
        return strategy


class StrategyExecutor:
    """策略执行器 — 在检索时应用策略"""
    
    def __init__(self, strategies: List[Dict]):
        self.strategies = strategies
    
    def apply(self, query: str, results: List[Dict]) -> List[Dict]:
        """
        应用所有匹配的策略到检索结果
        
        Args:
            query: 检索查询
            results: 原始检索结果
        
        Returns:
            策略调整后的结果
        """
        if not results:
            return results
        
        adjusted = [dict(r) for r in results]  # 深拷贝
        
        for strategy in self.strategies:
            if not strategy.get("enabled", True):
                continue
            
            stype = strategy.get("type")
            action = strategy.get("action", {})
            
            if stype == "category_filter":
                # 分类过滤：给目标分类的结果加分
                target_cat = action.get("category", "")
                boost = action.get("min_score_boost", 0.1)
                
                for r in adjusted:
                    if r.get("category") == target_cat:
                        r["score"] = r.get("score", 0) + boost
                        r["_strategy_applied"] = strategy["id"]
            
            elif stype == "category_demote":
                # 分类降权：给目标分类的结果扣分
                target_cat = action.get("category", "")
                penalty = action.get("penalty", 0.1)
                
                for r in adjusted:
                    if r.get("category") == target_cat:
                        r["score"] = max(0, r.get("score", 0) - penalty)
                        r["_strategy_applied"] = strategy["id"]
            
            elif stype == "keyword_expansion":
                # 关键词扩展：标记需要扩展（由调用方处理）
                keyword = action.get("keyword", "")
                if keyword.lower() in query.lower():
                    for r in adjusted:
                        r["_needs_expansion"] = True
                        r["_expansion_keyword"] = keyword
                        r["_strategy_applied"] = strategy["id"]
        
        # 重新排序
        adjusted.sort(key=lambda x: x.get("score", 0), reverse=True)
        return adjusted
    
    def record_outcome(self, strategy_id: str, success: bool):
        """记录策略执行结果"""
        # 由调用方在知道结果后调用
        pass


class SelfEvolutionEngine:
    """自我进化引擎 — 主入口"""
    
    def __init__(self):
        self.collector = FeedbackCollector()
        self._load_config()
        self.executor = StrategyExecutor(self.config.get("strategies", []))
    
    def _load_config(self):
        if os.path.exists(STRATEGY_DB):
            with open(STRATEGY_DB, "r", encoding="utf-8") as f:
                self.config = json.load(f)
        else:
            self.config = EvolutionConfig.DEFAULT.copy()
            self.config["created_at"] = datetime.utcnow().isoformat()
            self._save()
    
    def _save(self):
        os.makedirs(EVOLUTION_DIR, exist_ok=True)
        with open(STRATEGY_DB, "w", encoding="utf-8") as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)
    
    # ---- 公开 API ----
    
    def record_feedback(self, query: str, results: List[Dict], used: bool = False,
                        expected_category: str = None, actual_category: str = None,
                        correction: str = None):
        """
        记录反馈并触发进化检查
        """
        fb = self.collector.record(
            query, results, used,
            expected_category, actual_category, correction
        )
        
        self.config["total_feedback"] += 1
        if correction:
            self.config["total_corrections"] += 1
        
        # 每 5 条反馈触发一次进化分析
        if self.config["total_feedback"] % 5 == 0:
            self._evolve()
        
        return fb
    
    def apply_strategies(self, query: str, results: List[Dict]) -> List[Dict]:
        """
        在检索后应用已学习的策略
        """
        return self.executor.apply(query, results)
    
    def record_strategy_outcome(self, strategy_id: str, success: bool):
        """记录策略执行结果"""
        for s in self.config.get("strategies", []):
            if s["id"] == strategy_id:
                s["stats"]["times_triggered"] += 1
                if success:
                    s["stats"]["successes"] += 1
                else:
                    s["stats"]["failures"] += 1
                
                total = s["stats"]["successes"] + s["stats"]["failures"]
                if total > 0:
                    s["stats"]["effectiveness"] = round(
                        s["stats"]["successes"] / total, 3
                    )
                break
        
        self._save()
    
    def get_status(self) -> Dict:
        """获取进化状态"""
        strategies = self.config.get("strategies", [])
        active = [s for s in strategies if s.get("enabled", True)]
        
        status = {
            "version": self.config.get("version", "2.0.0"),
            "evolution_level": self.config.get("evolution_level", 1),
            "evolution_count": self.config.get("evolution_count", 0),
            "total_feedback": self.config.get("total_feedback", 0),
            "total_corrections": self.config.get("total_corrections", 0),
            "strategies": {
                "total": len(strategies),
                "active": len(active),
                "by_level": {
                    1: len([s for s in strategies if s.get("level") == 1]),
                    2: len([s for s in strategies if s.get("level") == 2]),
                    3: len([s for s in strategies if s.get("level") == 3]),
                },
            },
            "parameters": self.config.get("parameters", {}),
        }
        
        # Level 4: 架构反思状态
        issues = self.config.get("architectural_issues", [])
        if issues:
            status["architectural_reflection"] = {
                "total_issues": len(issues),
                "critical": len([i for i in issues if i.get("level") == "critical"]),
                "warning": len([i for i in issues if i.get("level") == "warning"]),
                "info": len([i for i in issues if i.get("level") == "info"]),
                "last_reflection": self.config.get("last_reflection"),
            }
        
        return status
        
        # Level 4: 架构反思状态
        issues = self.config.get("architectural_issues", [])
        if issues:
            critical = len([i for i in issues if i.get("level") == "critical"])
            warning = len([i for i in issues if i.get("level") == "warning"])
            info = len([i for i in issues if i.get("level") == "info"])
            status["architectural_reflection"] = {
                "total_issues": len(issues),
                "critical": critical,
                "warning": warning,
                "info": info,
                "last_reflection": self.config.get("last_reflection"),
            }
        
        return status
    
    def get_strategies(self) -> List[Dict]:
        """获取所有策略"""
        return self.config.get("strategies", [])
    
    def get_report(self) -> Dict:
        """生成进化报告"""
        strategies = self.config.get("strategies", [])
        
        report = {
            "timestamp": datetime.utcnow().isoformat(),
            "evolution_level": self.config.get("evolution_level", 1),
            "evolution_count": self.config.get("evolution_count", 0),
            "total_feedback": self.config.get("total_feedback", 0),
            "total_corrections": self.config.get("total_corrections", 0),
            "parameters": self.config.get("parameters", {}),
            "strategies": [],
            "insights": [],
        }
        
        for s in strategies:
            report["strategies"].append({
                "id": s["id"],
                "name": s["name"],
                "type": s["type"],
                "level": s["level"],
                "enabled": s.get("enabled", True),
                "effectiveness": s["stats"].get("effectiveness", 0),
                "triggers": s["stats"].get("times_triggered", 0),
            })
        
        # 生成洞察
        corrections = self.config.get("total_corrections", 0)
        feedback = self.config.get("total_feedback", 1)
        if corrections > 0:
            report["insights"].append(
                f"用户纠正率: {corrections/feedback*100:.1f}% — "
                f"{'较高，建议关注' if corrections/feedback > 0.2 else '正常'}"
            )
        
        low_effectiveness = [s for s in strategies 
                           if s["stats"].get("effectiveness", 1) < 0.3 
                           and s["stats"].get("times_triggered", 0) > 3]
        if low_effectiveness:
            report["insights"].append(
                f"低效策略: {len(low_effectiveness)} 条 — 建议审查或淘汰"
            )
        
        # Level 4: 架构反思洞察
        issues = self.config.get("architectural_issues", [])
        if issues:
            report["architectural_reflection"] = {
                "total_issues": len(issues),
                "critical": len([i for i in issues if i.get("level") == "critical"]),
                "warning": len([i for i in issues if i.get("level") == "warning"]),
                "info": len([i for i in issues if i.get("level") == "info"]),
                "summary": ArchitecturalReflector.generate_summary(issues),
                "issues": issues,
            }
            
            # 将严重问题加入洞察
            critical = [i for i in issues if i.get("level") == "critical"]
            if critical:
                for issue in critical:
                    report["insights"].append(f" [{issue['type']}] {issue['title']}: {issue['suggestion']}")
        
        return report
    
    # ---- 内部进化逻辑 ----
    
    def _evolve(self):
        """执行进化分析"""
        feedbacks = self.collector.get_recent(200)
        if len(feedbacks) < 5:
            return
        
        new_strategies = []
        
        # Level 1: 参数调优
        self._optimize_parameters(feedbacks)
        
        # Level 2: 规则/策略发现
        patterns = []
        patterns.extend(PatternAnalyzer.analyze_misclassifications(feedbacks))
        patterns.extend(PatternAnalyzer.analyze_empty_results(feedbacks))
        patterns.extend(PatternAnalyzer.analyze_unused_results(feedbacks))
        
        for pattern in patterns:
            strategy = None
            if pattern["type"] == "category_misclassification":
                strategy = StrategyGenerator.generate_category_filter_rule(pattern)
            elif pattern["type"] == "frequent_empty":
                strategy = StrategyGenerator.generate_keyword_expansion_rule(pattern)
            elif pattern["type"] == "low_utilization":
                strategy = StrategyGenerator.generate_category_demote_rule(pattern)
            
            if strategy:
                # 检查是否已存在
                existing_ids = {s["id"] for s in self.config.get("strategies", [])}
                if strategy["id"] not in existing_ids:
                    new_strategies.append(strategy)
        
        if new_strategies:
            self.config.setdefault("strategies", []).extend(new_strategies)
            self.config["evolution_count"] += 1
            self.config["last_evolved"] = datetime.utcnow().isoformat()
            
            # 更新进化层级
            max_level = max((s.get("level", 1) for s in self.config.get("strategies", [])), default=1)
            self.config["evolution_level"] = max(1, max_level)
            
            # 更新执行器
            self.executor = StrategyExecutor(self.config.get("strategies", []))
            
            self._save()
        
        # Level 4: 架构反思（每 15 条反馈执行一次）
        if self.config["total_feedback"] % 15 == 0:
            self._architectural_reflection(feedbacks)
    
    def _optimize_parameters(self, feedbacks: List[Dict]):
        """Level 1: 参数调优"""
        retrievals = [fb for fb in feedbacks if fb.get("result_count", 0) > 0]
        if not retrievals:
            return
        
        avg_score = sum(fb.get("top_score", 0) for fb in retrievals) / len(retrievals)
        usage_rate = sum(1 for fb in retrievals if fb.get("used")) / len(retrievals)
        
        params = self.config.get("parameters", {})
        
        # 低分 → 增加语义权重
        if avg_score < 0.3:
            params["vector_weight"] = min(0.9, params.get("vector_weight", 0.7) + 0.05)
            params["bm25_weight"] = 1.0 - params["vector_weight"]
        
        # 高使用率 → 提高置信度
        elif usage_rate > 0.7:
            params["min_confidence"] = min(0.3, params.get("min_confidence", 0.1) + 0.02)
        
        self.config["parameters"] = params
    
    def _architectural_reflection(self, feedbacks: List[Dict]):
        """Level 4: 架构反思 — 发现系统性问题并报告"""
        issues = ArchitecturalReflector.analyze(
            feedbacks,
            self.config.get("strategies", []),
            self.config.get("parameters", {})
        )
        
        if issues:
            # 保存架构反思结果
            self.config.setdefault("architectural_issues", []).extend(issues)
            self.config["last_reflection"] = datetime.utcnow().isoformat()
            
            # 更新进化层级到 Level 4
            self.config["evolution_level"] = max(self.config.get("evolution_level", 1), 4)
            self.config["evolution_count"] += 1
            
            # 生成反思报告
            summary = ArchitecturalReflector.generate_summary(issues)
            
            # 保存到报告目录
            os.makedirs(REPORT_DIR, exist_ok=True)
            report_file = os.path.join(REPORT_DIR, f"reflection-{int(time.time())}.json")
            with open(report_file, "w", encoding="utf-8") as f:
                json.dump({
                    "timestamp": datetime.utcnow().isoformat(),
                    "feedback_count": len(feedbacks),
                    "issues": issues,
                    "summary": summary,
                }, f, indent=2, ensure_ascii=False)
            
            self._save()
    
    def get_architectural_issues(self) -> List[Dict]:
        """获取架构反思发现的问题"""
        return self.config.get("architectural_issues", [])


class ArchitecturalReflector:
    """Level 4: 架构反思 — 发现系统性问题并报告
    
    不是修修补补，而是反思整个系统哪里出了问题。
    """
    
    SEVERITY_CRITICAL = "critical"    # 必须立即修复
    SEVERITY_WARNING = "warning"      # 需要关注
    SEVERITY_INFO = "info"           # 建议优化
    
    @staticmethod
    def analyze(feedbacks: List[Dict], strategies: List[Dict], parameters: Dict) -> List[Dict]:
        """
        全面架构分析，返回发现的问题列表
        """
        issues = []
        
        # 1. 检索质量系统性下降
        issues.extend(ArchitecturalReflector._check_retrieval_degradation(feedbacks))
        
        # 2. 分类覆盖不均
        issues.extend(ArchitecturalReflector._check_category_coverage(feedbacks))
        
        # 3. 策略失效循环
        issues.extend(ArchitecturalReflector._check_strategy_ineffectiveness(strategies))
        
        # 4. 反馈模式异常
        issues.extend(ArchitecturalReflector._check_feedback_anomalies(feedbacks))
        
        # 5. 参数漂移警告
        issues.extend(ArchitecturalReflector._check_parameter_drift(parameters))
        
        # 6. 记忆库健康度
        issues.extend(ArchitecturalReflector._check_memory_health(feedbacks))
        
        return issues
    
    @staticmethod
    def _check_retrieval_degradation(feedbacks: List[Dict]) -> List[Dict]:
        """检查检索质量是否系统性下降"""
        issues = []
        retrievals = [fb for fb in feedbacks if fb.get("result_count", 0) > 0]
        
        if len(retrievals) < 5:
            return issues
        
        # 按时间分段比较
        mid = len(retrievals) // 2
        old = retrievals[:mid]
        new = retrievals[mid:]
        
        old_score = sum(fb.get("top_score", 0) for fb in old) / len(old)
        new_score = sum(fb.get("top_score", 0) for fb in new) / len(new)
        
        old_usage = sum(1 for fb in old if fb.get("used")) / len(old)
        new_usage = sum(1 for fb in new if fb.get("used")) / len(new)
        
        # 分数下降超过 20%
        if old_score > 0 and new_score < old_score * 0.8:
            drop_pct = round((old_score - new_score) / old_score * 100, 1)
            issues.append({
                "level": "critical",
                "type": "retrieval_degradation",
                "title": f"检索质量系统性下降 {drop_pct}%",
                "description": (
                    f"最近 {len(new)} 次检索的平均分 ({new_score:.3f}) "
                    f"比之前 {len(old)} 次 ({old_score:.3f}) 低 {drop_pct}%。"
                    f"可能原因：记忆库内容过时、嵌入模型不适用、或检索策略偏差。"
                ),
                "suggestion": "建议检查记忆库内容时效性，考虑重新训练嵌入模型或调整检索策略。",
                "metrics": {
                    "old_avg_score": round(old_score, 3),
                    "new_avg_score": round(new_score, 3),
                    "drop_percentage": drop_pct,
                }
            })
        
        # 使用率下降超过 30%
        if old_usage > 0 and new_usage < old_usage * 0.7:
            drop_pct = round((old_usage - new_usage) / old_usage * 100, 1)
            issues.append({
                "level": "warning",
                "type": "usage_rate_decline",
                "title": f"检索结果使用率下降 {drop_pct}%",
                "description": (
                    f"最近检索结果的使用率从 {old_usage:.0%} 降到 {new_usage:.0%}。"
                    f"用户越来越不信任检索结果。"
                ),
                "suggestion": "建议审查检索策略，增加结果多样性或改进排序算法。",
                "metrics": {
                    "old_usage_rate": round(old_usage, 3),
                    "new_usage_rate": round(new_usage, 3),
                }
            })
        
        return issues
    
    @staticmethod
    def _check_category_coverage(feedbacks: List[Dict]) -> List[Dict]:
        """检查分类覆盖是否均匀"""
        issues = []
        
        cat_stats = defaultdict(lambda: {"total": 0, "empty": 0, "avg_score": 0, "scores": []})
        
        for fb in feedbacks:
            cat = fb.get("top_category", "unknown") or "unknown"
            cat_stats[cat]["total"] += 1
            cat_stats[cat]["scores"].append(fb.get("top_score", 0))
            if fb.get("result_count", 0) == 0:
                cat_stats[cat]["empty"] += 1
        
        for cat, stats in cat_stats.items():
            if stats["total"] < 3:
                continue
            
            stats["avg_score"] = sum(stats["scores"]) / len(stats["scores"]) if stats["scores"] else 0
            empty_rate = stats["empty"] / stats["total"]
            
            # 某分类空结果率过高
            if empty_rate > 0.4:
                issues.append({
                    "level": "warning",
                    "type": "category_coverage_gap",
                    "title": f"分类 '{cat}' 覆盖率不足 ({(1-empty_rate):.0%})",
                    "description": (
                        f"针对 '{cat}' 分类的查询中 {empty_rate:.0%} 返回空结果。"
                        f"该分类记忆数量可能不足，或嵌入向量质量差。"
                    ),
                    "suggestion": f"建议增加 '{cat}' 分类的记忆数量，或检查该分类的嵌入质量。",
                    "metrics": {
                        "category": cat,
                        "empty_rate": round(empty_rate, 3),
                        "total_queries": stats["total"],
                    }
                })
        
        # 检查是否有分类完全没被查询到
        all_cats = set(fb.get("top_category", "") for fb in feedbacks if fb.get("top_category"))
        if len(all_cats) <= 1 and len(feedbacks) > 5:
            issues.append({
                "level": "info",
                "type": "single_category_dominance",
                "title": "检索结果集中在单一分类",
                "description": (
                    f"最近 {len(feedbacks)} 次检索结果主要来自 {len(all_cats)} 个分类。"
                    f"这可能意味着记忆库分类不均衡，或者某些分类的记忆质量远高于其他。"
                ),
                "suggestion": "建议检查各分类的记忆数量分布，确保均衡覆盖。",
                "metrics": {"unique_categories": len(all_cats), "categories": list(all_cats)}
            })
        
        return issues
    
    @staticmethod
    def _check_strategy_ineffectiveness(strategies: List[Dict]) -> List[Dict]:
        """检查策略是否失效"""
        issues = []
        
        for s in strategies:
            if not s.get("enabled", True):
                continue
            
            stats = s.get("stats", {})
            triggered = stats.get("times_triggered", 0)
            effectiveness = stats.get("effectiveness", 0)
            
            # 策略频繁触发但效果差
            if triggered > 5 and effectiveness < 0.3:
                issues.append({
                    "level": "critical",
                    "type": "strategy_ineffective",
                    "title": f"策略 '{s['name']}' 失效",
                    "description": (
                        f"策略 '{s['name']}' 已触发 {triggered} 次，"
                        f"但有效率仅 {effectiveness:.0%}。"
                        f"该策略可能不适用于当前场景。"
                    ),
                    "suggestion": f"建议禁用或重新设计策略 '{s['id']}'。",
                    "metrics": {
                        "strategy_id": s["id"],
                        "triggered": triggered,
                        "effectiveness": effectiveness,
                    }
                })
            
            # 策略从未触发过
            elif triggered == 0:
                issues.append({
                    "level": "info",
                    "type": "strategy_unused",
                    "title": f"策略 '{s['name']}' 从未触发",
                    "description": f"策略 '{s['name']}' 创建后从未被触发过，可能条件过于严格。",
                    "suggestion": f"建议放宽触发条件或删除该策略。",
                    "metrics": {"strategy_id": s["id"]}
                })
        
        return issues
    
    @staticmethod
    def _check_feedback_anomalies(feedbacks: List[Dict]) -> List[Dict]:
        """检查反馈模式异常"""
        issues = []
        
        if len(feedbacks) < 10:
            return issues
        
        # 检查连续空结果
        consecutive_empty = 0
        max_consecutive_empty = 0
        for fb in feedbacks:
            if fb.get("result_count", 0) == 0:
                consecutive_empty += 1
                max_consecutive_empty = max(max_consecutive_empty, consecutive_empty)
            else:
                consecutive_empty = 0
        
        if max_consecutive_empty >= 3:
            issues.append({
                "level": "critical",
                "type": "consecutive_empty_results",
                "title": f"连续 {max_consecutive_empty} 次空检索结果",
                "description": (
                    f"系统出现了连续 {max_consecutive_empty} 次查询返回空结果。"
                    f"这表明检索系统可能存在盲区或记忆库覆盖严重不足。"
                ),
                "suggestion": "紧急检查记忆库覆盖范围，补充缺失分类的记忆。",
                "metrics": {"max_consecutive_empty": max_consecutive_empty}
            })
        
        # 检查纠正率
        corrections = [fb for fb in feedbacks if fb.get("type") == "correction"]
        correction_rate = len(corrections) / len(feedbacks)
        if correction_rate > 0.15:
            issues.append({
                "level": "warning",
                "type": "high_correction_rate",
                "title": f"用户纠正率过高 ({correction_rate:.0%})",
                "description": (
                    f"{len(corrections)}/{len(feedbacks)} 次反馈是用户纠正。"
                    f"系统返回的结果经常不符合用户期望。"
                ),
                "suggestion": "建议分析纠正模式，针对性优化检索策略。",
                "metrics": {"correction_rate": round(correction_rate, 3)}
            })
        
        return issues
    
    @staticmethod
    def _check_parameter_drift(parameters: Dict) -> List[Dict]:
        """检查参数漂移"""
        issues = []
        
        vw = parameters.get("vector_weight", 0.7)
        bw = parameters.get("bm25_weight", 0.3)
        
        # 语义权重被推到极限
        if vw >= 0.9:
            issues.append({
                "level": "warning",
                "type": "parameter_extreme",
                "title": "语义权重已达上限 (0.9)",
                "description": (
                    f"语义权重已升至 {vw}，接近上限。"
                    f"这表明 BM25 关键词匹配效果很差，"
                    f"可能需要更好的关键词提取或同义词扩展。"
                ),
                "suggestion": "考虑引入查询扩展或同义词映射来增强 BM25 效果。",
                "metrics": {"vector_weight": vw, "bm25_weight": bw}
            })
        
        # 置信度被推到过高
        mc = parameters.get("min_confidence", 0.1)
        if mc >= 0.25:
            issues.append({
                "level": "info",
                "type": "high_min_confidence",
                "title": f"最小置信度偏高 ({mc:.2f})",
                "description": (
                    f"最小置信度已升至 {mc:.2f}，这可能导致部分有效结果被过滤。"
                ),
                "suggestion": "监控是否有用户反馈结果太少。",
                "metrics": {"min_confidence": mc}
            })
        
        return issues
    
    @staticmethod
    def _check_memory_health(feedbacks: List[Dict]) -> List[Dict]:
        """检查记忆库健康度"""
        issues = []
        
        if not feedbacks:
            return issues
        
        # 空结果率整体过高
        total = len(feedbacks)
        empty = sum(1 for fb in feedbacks if fb.get("result_count", 0) == 0)
        empty_rate = empty / total if total > 0 else 0
        
        if empty_rate > 0.3:
            issues.append({
                "level": "critical",
                "type": "low_memory_coverage",
                "title": f"记忆库覆盖率低 (空结果率 {empty_rate:.0%})",
                "description": (
                    f"{empty}/{total} 次检索返回空结果。"
                    f"记忆库内容不足以覆盖查询范围。"
                ),
                "suggestion": "需要大量补充记忆，特别是查询频繁但结果为空的领域。",
                "metrics": {"empty_rate": round(empty_rate, 3), "empty_count": empty, "total": total}
            })
        
        # 平均分过低
        non_empty = [fb for fb in feedbacks if fb.get("result_count", 0) > 0]
        if non_empty:
            avg_score = sum(fb.get("top_score", 0) for fb in non_empty) / len(non_empty)
            if avg_score < 0.2:
                issues.append({
                    "level": "warning",
                    "type": "low_relevance",
                    "title": f"检索相关性低 (平均分 {avg_score:.3f})",
                    "description": (
                        f"检索结果的平均分仅 {avg_score:.3f}，"
                        f"说明返回的结果和查询相关性不高。"
                    ),
                    "suggestion": "检查嵌入模型质量，或考虑使用更强的嵌入模型。",
                    "metrics": {"avg_score": round(avg_score, 3)}
                })
        
        return issues
    
    @staticmethod
    def generate_summary(issues: List[Dict]) -> str:
        """生成架构反思摘要"""
        if not issues:
            return "系统运行正常，未发现架构级问题。"
        
        critical = [i for i in issues if i["level"] == "critical"]
        warning = [i for i in issues if i["level"] == "warning"]
        info = [i for i in issues if i["level"] == "info"]
        
        lines = [f"发现 {len(issues)} 个问题："]
        if critical:
            lines.append(f"   严重 {len(critical)} 个: {'; '.join(i['title'] for i in critical)}")
        if warning:
            lines.append(f"   警告 {len(warning)} 个: {'; '.join(i['title'] for i in warning)}")
        if info:
            lines.append(f"   建议 {len(info)} 个: {'; '.join(i['title'] for i in info)}")
        
        return "\n".join(lines)


# ---- CLI 入口 ----

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Arshis Self-Evolution Engine v2.0")
    sub = parser.add_subparsers(dest="command")
    
    sub.add_parser("status", help="Show evolution status")
    sub.add_parser("strategies", help="List all strategies")
    sub.add_parser("issues", help="Show architectural reflection issues (Level 4)")
    sub.add_parser("report", help="Generate evolution report")
    sub.add_parser("reset", help="Reset all evolution data")
    
    args = parser.parse_args()
    
    engine = SelfEvolutionEngine()
    
    if args.command == "status":
        print(json.dumps(engine.get_status(), indent=2, ensure_ascii=False))
    elif args.command == "strategies":
        print(json.dumps(engine.get_strategies(), indent=2, ensure_ascii=False))
    elif args.command == "issues":
        issues = engine.get_architectural_issues()
        if issues:
            summary = ArchitecturalReflector.generate_summary(issues)
            print(summary)
            print()
            for i, issue in enumerate(issues, 1):
                level_icon = {"critical": "", "warning": "", "info": ""}.get(issue.get("level", "info"), "")
                print(f"{level_icon} [{i}] {issue['title']}")
                print(f"    Type: {issue['type']}")
                print(f"    Level: {issue['level']}")
                print(f"    {issue['description']}")
                print(f"    → {issue['suggestion']}")
                if issue.get('metrics'):
                    print(f"    Metrics: {json.dumps(issue['metrics'], ensure_ascii=False)}")
                print()
        else:
            print("No architectural issues detected. System is healthy.")
    elif args.command == "report":
        print(json.dumps(engine.get_report(), indent=2, ensure_ascii=False))
    elif args.command == "reset":
        import shutil
        if os.path.exists(EVOLUTION_DIR):
            shutil.rmtree(EVOLUTION_DIR)
        print('{"status": "reset"}')
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
