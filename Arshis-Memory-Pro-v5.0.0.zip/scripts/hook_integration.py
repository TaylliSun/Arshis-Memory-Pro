#!/usr/bin/env python3
"""
Hook Integration for Arshis-memory-pro

Provides OpenClaw hooks for:
- Dreaming mode integration
- Sleep tracking data
- Memory statistics
- Platform API: wiki.importInsights
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, Optional

# Export all public APIs
__all__ = [
    'HookIntegration',
    'get_dreaming_data',
    'get_stats',
    'get_plugin_info',
    'wiki_importInsights',
    'wiki_palace',
    'importInsights',
    'register',
    'activate'
]


def register():
    """Plugin registration for OpenClaw"""
    return {
        "name": "Arshis-memory-pro",
        "version": "3.3.6",
        "apis": [
            "get_dreaming_data",
            "wiki_importInsights",
            "wiki_palace",
            "get_stats",
            "get_plugin_info"
        ]
    }


def activate():
    """Plugin activation for OpenClaw"""
    return {
        "status": "active",
        "dreaming_enabled": True,
        "version": "3.3.6"
    }


class HookIntegration:
    """OpenClaw Hook Integration"""
    
    def __init__(self):
        """Initialize Hook Integration"""
        self.config_path = "/root/.openclaw/data/memory-custom-config.json"
        self.dreams_path = "/root/.openclaw/data/memory-custom/dreams.json"
        self.sleep_path = "/root/.openclaw/data/memory-custom/sleep.json"
    
    def get_dreaming_status(self) -> Dict[str, Any]:
        """
        Get dreaming mode status for platform UI
        
        Returns:
            Dreaming status dictionary
        """
        # Load config
        config = {}
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
        
        # Check if dreaming is enabled
        dreaming_enabled = config.get('features', {}).get('dreaming', False)
        
        # Load dreams
        dreams = []
        if os.path.exists(self.dreams_path):
            with open(self.dreams_path, 'r', encoding='utf-8') as f:
                dreams = json.load(f)
        
        # Load sleep data
        sleep_data = []
        if os.path.exists(self.sleep_path):
            with open(self.sleep_path, 'r', encoding='utf-8') as f:
                sleep_data = json.load(f)
        
        # Get last night's sleep
        last_night = sleep_data[-1] if sleep_data else None
        
        # Calculate improvements
        total_improvements = sum(len(d.get('improvements', [])) for d in dreams)
        if last_night:
            total_improvements += last_night.get('improvements', 0)
        
        # Return platform-compatible format
        return {
            "enabled": dreaming_enabled,
            "light_sleep": last_night.get('light_sleep_min', 0) if last_night else 0,
            "deep_sleep": last_night.get('deep_sleep_min', 0) if last_night else 0,
            "rem_sleep": last_night.get('rem_sleep_min', 0) if last_night else 0,
            "total_sleep": last_night.get('total_sleep_min', 0) if last_night else 0,
            "quality": last_night.get('quality', 0) if last_night else 0,
            "dreams": len(dreams),
            "improvements": total_improvements,
            "consolidated": last_night.get('consolidated', False) if last_night else False
        }
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get memory statistics for platform UI
        
        Returns:
            Memory statistics dictionary
        """
        memories_path = "/root/.openclaw/data/memory-custom/memories.json"
        
        if not os.path.exists(memories_path):
            return {
                "total_memories": 0,
                "categories": {},
                "avg_importance": 0
            }
        
        with open(memories_path, 'r', encoding='utf-8') as f:
            memories = json.load(f)
        
        # Calculate statistics
        total = len(memories)
        categories = {}
        importance_sum = 0
        
        for memory in memories:
            category = memory.get('category', 'Unknown')
            categories[category] = categories.get(category, 0) + 1
            importance_sum += memory.get('importance', 0.5)
        
        return {
            "total_memories": total,
            "categories": categories,
            "avg_importance": round(importance_sum / total, 2) if total > 0 else 0
        }
    
    def get_plugin_info(self) -> Dict[str, Any]:
        """
        Get plugin information for platform UI
        
        Returns:
            Plugin information dictionary
        """
        return {
            "name": "Arshis-memory-pro",
            "version": "3.3.0",
            "author": "Arshis",
            "features": {
                "multi_provider": True,
                "auto_failover": True,
                "hybrid_retrieval": True,
                "dreaming": True,
                "sleep_tracking": True,
                "cache": True,
                "statistics": True
            }
        }


def get_plugin_info() -> Dict[str, Any]:
    """
    Get plugin information for platform UI
    
    Returns:
        Plugin information dictionary
    """
    return {
        "name": "Arshis-memory-pro",
        "version": "3.3.6",
        "author": "Arshis",
        "features": {
            "multi_provider": True,
            "auto_failover": True,
            "hybrid_retrieval": True,
            "dreaming": True,
            "sleep_tracking": True,
            "cache": True,
            "statistics": True
        }
    }


# Platform API endpoints
def dreaming_api():
    """API endpoint for dreaming data"""
    hooks = HookIntegration()
    return hooks.get_dreaming_status()


def memory_stats_api():
    """API endpoint for memory statistics"""
    hooks = HookIntegration()
    return hooks.get_memory_stats()


def plugin_info_api():
    """API endpoint for plugin information"""
    hooks = HookIntegration()
    return hooks.get_plugin_info()


# OpenClaw Hook functions
def before_agent_start(context):
    """Hook: Before agent starts"""
    # Auto-recall if enabled
    config_path = "/root/.openclaw/data/memory-custom-config.json"
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        if config.get('features', {}).get('autoRecall', False):
            # Trigger memory recall
            pass
    
    return context


def after_agent_reply(context, reply):
    """Hook: After agent replies"""
    # Auto-capture if enabled
    config_path = "/root/.openclaw/data/memory-custom-config.json"
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        if config.get('features', {}).get('autoCapture', False):
            # Capture conversation to memory
            pass
    
    return reply


def get_dreaming_data():
    """Hook: Get dreaming data for platform UI"""
    hooks = HookIntegration()
    return hooks.get_dreaming_status()


def get_stats():
    """Hook: Get statistics for platform UI"""
    hooks = HookIntegration()
    return {
        "dreaming": hooks.get_dreaming_status(),
        "memory": hooks.get_memory_stats(),
        "plugin": hooks.get_plugin_info()
    }


def wiki_importInsights(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Platform API: Import insights (sleep/dream data)
    Method name: wiki.importInsights (as expected by platform)
    
    This method is called by the platform to import sleep/dream data.
    
    Args:
        data: Insight data from platform
            {
                "type": "sleep" | "dream",
                "date": "YYYY-MM-DD",
                "light_sleep": 240,
                "deep_sleep": 90,
                "rem_sleep": 120,
                "dreams": [...],
                "quality": 4
            }
    
    Returns:
        Result dictionary
    """
    try:
        insight_type = data.get('type', 'sleep')
        
        if insight_type == 'sleep':
            # Import sleep data
            sleep_path = "/root/.openclaw/data/memory-custom/sleep.json"
            sleep_data = []
            
            if os.path.exists(sleep_path):
                with open(sleep_path, 'r', encoding='utf-8') as f:
                    sleep_data = json.load(f)
            
            # Add new sleep entry
            new_entry = {
                "id": len(sleep_data) + 1,
                "date": data.get('date', datetime.now().strftime('%Y-%m-%d')),
                "light_sleep_min": data.get('light_sleep', 0),
                "deep_sleep_min": data.get('deep_sleep', 0),
                "rem_sleep_min": data.get('rem_sleep', 0),
                "total_sleep_min": data.get('light_sleep', 0) + data.get('deep_sleep', 0) + data.get('rem_sleep', 0),
                "quality": data.get('quality', 3),
                "dreams": data.get('dreams', []),
                "improvements": len(data.get('dreams', [])),
                "consolidated": False,
                "source": "platform_import"
            }
            
            sleep_data.append(new_entry)
            
            with open(sleep_path, 'w', encoding='utf-8') as f:
                json.dump(sleep_data, f, indent=2, ensure_ascii=False)
            
            return {
                "success": True,
                "message": f"Imported sleep data for {new_entry['date']}",
                "id": new_entry['id']
            }
        
        elif insight_type == 'dream':
            # Import dream data
            dreams_path = "/root/.openclaw/data/memory-custom/dreams.json"
            dreams = []
            
            if os.path.exists(dreams_path):
                with open(dreams_path, 'r', encoding='utf-8') as f:
                    dreams = json.load(f)
            
            # Add new dream
            new_dream = {
                "id": len(dreams) + 1,
                "content": data.get('content', ''),
                "created_at": data.get('created_at', datetime.now().isoformat()),
                "category": data.get('category', '梦境/灵感'),
                "tags": data.get('tags', []),
                "consolidated": False,
                "improvements": [],
                "source": "platform_import"
            }
            
            dreams.append(new_dream)
            
            with open(dreams_path, 'w', encoding='utf-8') as f:
                json.dump(dreams, f, indent=2, ensure_ascii=False)
            
            return {
                "success": True,
                "message": "Imported dream data",
                "id": new_dream['id']
            }
        
        else:
            return {
                "success": False,
                "message": f"Unknown insight type: {insight_type}"
            }
    
    except Exception as e:
        return {
            "success": False,
            "message": f"Error importing insights: {str(e)}"
        }


# Alias for backward compatibility
importInsights = wiki_importInsights


def wiki_palace(data: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Platform API: wiki.palace
    Placeholder method for platform compatibility
    
    Args:
        data: Optional data from platform
    
    Returns:
        Status dictionary
    """
    return {
        "success": True,
        "message": "Palace API is available",
        "status": "active",
        "dreaming_enabled": True,
        "version": "3.3.4"
    }


# Main function for testing
def main():
    """Main function for testing"""
    import sys
    
    hooks = HookIntegration()
    
    if len(sys.argv) < 2:
        print("\nArshis-memory-pro Hook Integration")
        print("=" * 60)
        print("\nUsage:")
        print("  python3 hook_integration.py dreaming    # Get dreaming data")
        print("  python3 hook_integration.py stats       # Get all stats")
        print("  python3 hook_integration.py info        # Get plugin info")
        print()
        return
    
    command = sys.argv[1]
    
    if command == "dreaming":
        data = hooks.get_dreaming_status()
        print("\nDreaming Data:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    
    elif command == "stats":
        data = hooks.get_stats()
        print("\nAll Statistics:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    
    elif command == "info":
        data = hooks.get_plugin_info()
        print("\nPlugin Info:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    
    else:
        print(f"[ERROR] Unknown command: {command}")


if __name__ == "__main__":
    main()
