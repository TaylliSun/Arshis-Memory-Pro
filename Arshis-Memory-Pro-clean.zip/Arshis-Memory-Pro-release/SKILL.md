---
name: Arshis-Memory-Pro
description: Advanced memory management system for AI agents with long-term storage, intelligent retrieval, and knowledge management capabilities.
author: TaylliSun (Arshis)
version: 1.0.0
license: MIT
---

# Arshis-Memory-Pro

**Advanced Memory System for AI Agents**

**Author**: TaylliSun (Arshis)  
**Version**: v1.0.0  
**License**: MIT

---

## 🎯 Core Features

### 1. Long-term Memory Storage
- **Capacity**: 100,000 memories (20K active + 80K archive)
- **Retention**: 730-day half-life with importance-based decay
- **Auto Capture**: Automatically saves important conversations
- **Smart Import**: Import from Markdown/JSON files

### 2. Intelligent Retrieval
- **Hybrid Search**: Vector (50%) + BM25 (50%)
- **Reranking**: Top-100 reranking for accuracy
- **Filters**: Category, tag, and time-range filtering
- **Speed**: <200ms retrieval time

### 3. Auto Organization
- **Categories**: 15 automatic categories
- **Tags**: Auto-tagging with up to 10 tags per memory
- **Summaries**: Automatic 50-character summaries
- **Relations**: Auto-discover related memories

### 4. Advanced Features
- **Dream Mode**: Record dreams/inspirations
- **Visualization**: Tag clouds, growth curves, category distributions
- **Reminders**: Scheduled reviews and project progress tracking
- **Project Isolation**: Separate memory libraries for different projects

---

## 📦 Installation

### Quick Install

```bash
# Download release
wget https://github.com/TaylliSun/Arshis-Memory-Pro/releases/download/v1.0/Arshis-Memory-Pro-clean.zip

# Extract to skills directory
unzip Arshis-Memory-Pro-clean.zip -d ~/.openclaw/workspace/skills/

# Verify installation
test -f ~/.openclaw/workspace/skills/Arshis-Memory-Pro-release/SKILL.md && echo "✅ Installation successful"
```

### Configuration

Add to `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "entries": {
      "Arshis-Memory-Pro": {
        "enabled": true,
        "config": {
          "autoCapture": true,
          "autoRecall": true,
          "recallLimit": 20,
          "injectMinLength": 5,
          "categories": ["Uncategorized", "Knowledge", "Ideas", "Other"],
          "maxMemories": 100000,
          "activeLimit": 20000,
          "archiveLimit": 80000,
          "decay": {
            "enabled": true,
            "halfLife": 730,
            "minImportance": 0.05
          },
          "retrieval": {
            "mode": "hybrid",
            "vectorWeight": 0.5,
            "bm25Weight": 0.5,
            "rerank": true,
            "rerankTopK": 100
          }
        }
      }
    }
  }
}
```

---

## 💻 Usage

### Basic Commands

```bash
# Save memory manually
#remember User prefers coffee over tea

# Search memories
#search user preferences

# Search by category
#search coffee category:preference

# Search by time range
#search recent 7 days

# View statistics
#memory-stats

# Export memories
#export ProjectName

# Import from file
#import /path/to/file.md
```

### Advanced Commands

```bash
# Record dream/inspiration
#dream Dreamt about flying character

# Review today's memories
#review-today

# Morning brief
#morning-brief

# Creative incubation
#incubate How to design engaging combat system

# View tag cloud
#tag-cloud

# Category distribution
#category-dist

# Growth curve (last 30 days)
#growth-curve 30

# Memory relationship graph
#memory-graph character

# Set reminder
#reminder weekly-review weekly

# View reminders
#list-reminders
```

---

## 🔧 API Reference

### Memory Core API

```bash
# Store memory
python3 scripts/memory_core.py store "Memory content" 0.7 knowledge

# Recall memories
python3 scripts/memory_core.py recall "Search keyword" 5

# View stats
python3 scripts/memory_core.py stats
```

### Advanced Search API

```bash
# Search with filters
python3 scripts/advanced_search.py "#search character category:role"

# Export memories
python3 scripts/advanced_search.py "#export ProjectName"

# Batch import
python3 scripts/advanced_search.py "#batch-import /path/to/docs"
```

### Dream Mode API

```bash
# Record dream
python3 scripts/dream_mode.py "#dream Flying in sky"

# Review today
python3 scripts/dream_mode.py "#review-today"

# Morning brief
python3 scripts/dream_mode.py "#morning-brief"
```

### Visualization API

```bash
# Tag cloud
python3 scripts/memory_visualization.py "#tag-cloud"

# Category distribution
python3 scripts/memory_visualization.py "#category-dist"

# Growth curve
python3 scripts/memory_visualization.py "#growth-curve 30"

# Memory graph
python3 scripts/memory_visualization.py "#memory-graph character"
```

---

## 📊 Performance

| Metric | Value |
|---|---|
| **Memory Capacity** | 100,000 memories |
| **Retrieval Speed** | <200ms (100K memories) |
| **Storage Size** | ~50MB (100K memories) |
| **Memory Usage** | ~1-2GB (100K memories) |
| **Half-life** | 730 days (2 years) |
| **Categories** | 15 auto categories |
| **Tags** | Up to 10 per memory |

---

## 📁 Project Structure

```
Arshis-Memory-Pro/
├── scripts/                      # Core scripts (14 files)
│   ├── memory_core.py           # Core memory functions
│   ├── advanced_search.py       # Advanced search
│   ├── dream_mode.py            # Dream mode
│   ├── memory_visualization.py  # Visualization
│   ├── memory_reminder.py       # Reminders
│   ├── memory_import.py         # Import/Export
│   ├── smart_summary.py         # Smart summary
│   ├── auto_capture.py          # Auto capture
│   ├── hook_integration.py      # Hook integration
│   ├── lifecycle.py             # Lifecycle management
│   ├── openclaw_integration.py  # OpenClaw integration
│   ├── self_improvement.py      # Self-improvement
│   ├── session_memory.py        # Session memory
│   └── smart_extract.py         # Smart extraction
├── SKILL.md                      # This file
└── HOOK_SETUP.md                 # Hook setup guide
```

---

## 🛠 Requirements

- **Python**: 3.8+
- **OpenClaw**: 1.0+
- **Dependencies**: None (pure Python standard library)
- **Platform**: Windows / Linux / macOS

---

## 📄 License

This project is licensed under the MIT License - commercial-friendly, free to use and modify.

```
MIT License

Copyright (c) 2026 TaylliSun (Arshis)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 🙏 Acknowledgments

Thanks to the following resources:
- SiliconFlow for embedding models (BAAI/bge-m3)
- LanceDB for vector storage
- OpenClaw platform for plugin system

---

## 📬 Contact

- **GitHub**: https://github.com/TaylliSun/Arshis-Memory-Pro
- **Issues**: https://github.com/TaylliSun/Arshis-Memory-Pro/issues
- **Author**: TaylliSun (Arshis)

---

*Arshis-Memory-Pro v1.0*  
*Advanced Memory System for AI Agents*  
*Author: TaylliSun (Arshis)*  
*License: MIT*
