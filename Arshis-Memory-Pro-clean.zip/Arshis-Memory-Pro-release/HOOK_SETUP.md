# Arshis-Memory-Pro - Hook 设置指南

**作者**: Arshis  
**版本**: v1.0

---

## 当前状态

Arshis-Memory-Pro 的 Hook 功能已通过测试，但 OpenClaw 的 Hook 系统需要特定配置。

---

## 方案 1: 使用 memory-lancedb 插件（推荐）

当前已配置的 `memory-lancedb` 插件支持自动捕获/注入：

```json
{
  "plugins": {
    "slots": {
      "memory": "memory-lancedb"
    },
    "entries": {
      "memory-lancedb": {
        "enabled": true,
        "config": {
          "autoCapture": true,
          "autoRecall": true
        }
      }
    }
  }
}
```

**优点**：
- ✅ 开箱即用
- ✅ 官方支持
- ✅ 无需额外配置

**缺点**：
- ⚠️ 无法使用 Arshis-Memory-Pro 的高级功能（分类差异化衰减等）

---

## 方案 2: 手动调用（当前可用）

通过脚本手动调用记忆功能：

```bash
# 存储记忆
python3 /root/.openclaw/workspace/skills/Arshis-Memory-Pro-release/scripts/memory_core.py store "记忆内容" 0.7 知识

# 检索记忆
python3 /root/.openclaw/workspace/skills/Arshis-Memory-Pro-release/scripts/memory_core.py recall "搜索关键词" 5
```

**优点**：
- ✅ 完全控制
- ✅ 可使用所有高级功能

**缺点**：
- ⚠️ 需要手动调用

---

## 推荐配置

使用 Arshis-Memory-Pro 作为主记忆系统：

```json
{
  "plugins": {
    "slots": {
      "memory": "Arshis-Memory-Pro"
    },
    "entries": {
      "Arshis-Memory-Pro": {
        "enabled": true,
        "config": {
          "autoCapture": true,
          "autoRecall": true,
          "recallLimit": 20,
          "injectMinLength": 5,
          "maxMemories": 100000,
          "decay": {
            "enabled": true,
            "halfLife": 730,
            "minImportance": 0.05
          }
        }
      }
    }
  }
}
```

---

*Arshis-Memory-Pro v1.0*  
*作者：Arshis*
