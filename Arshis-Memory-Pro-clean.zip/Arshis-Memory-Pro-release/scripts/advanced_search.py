#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高级检索功能

支持：
- #搜索 [关键词] - 全文搜索
- #查找 [分类] - 按分类查找
- #记忆统计 - 显示记忆统计信息
- #导出 [项目名] - 导出记忆
- #导入 [文件名] - 导入记忆
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Optional


class AdvancedSearch:
    """高级检索"""
    
    def __init__(self, memory_path: str = None):
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        
        self.memory_path = memory_path
        self.memories = []
        self.load_memories()
    
    def load_memories(self):
        """加载记忆"""
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
                print(f"✅ 已加载 {len(self.memories)} 条记忆", file=sys.stderr)
            else:
                print("⚠️ 记忆文件不存在", file=sys.stderr)
        except Exception as e:
            print(f"❌ 加载失败：{e}", file=sys.stderr)
            self.memories = []
    
    def search(self, keywords: str, category: str = None, tags: List[str] = None, 
               days: int = None, limit: int = 20) -> str:
        """
        搜索记忆
        
        Args:
            keywords: 关键词
            category: 分类
            tags: 标签列表
            days: 最近 N 天
            limit: 返回数量限制
        
        Returns:
            搜索结果
        """
        results = []
        
        for memory in self.memories:
            # 关键词匹配
            if keywords and keywords.lower() not in memory.get('text', '').lower():
                continue
            
            # 分类匹配
            if category and memory.get('category') != category:
                continue
            
            # 标签匹配
            if tags:
                memory_tags = memory.get('tags', [])
                if not any(tag in memory_tags for tag in tags):
                    continue
            
            # 时间匹配
            if days:
                created_at = memory.get('created_at', '')
                if created_at:
                    try:
                        memory_date = datetime.fromisoformat(created_at)
                        if datetime.now() - memory_date > timedelta(days=days):
                            continue
                    except:
                        pass
            
            results.append(memory)
            
            # 限制数量
            if len(results) >= limit:
                break
        
        # 生成结果
        if not results:
            return f"❌ 未找到相关记忆"
        
        response = f"🔍 找到 {len(results)} 条相关记忆：\n\n"
        
        for i, memory in enumerate(results[:10], 1):
            text = memory.get('text', '')[:100]
            if len(memory.get('text', '')) > 100:
                text += '...'
            
            category = memory.get('category', '未分类')
            importance = memory.get('importance', 0.5)
            created = memory.get('created_at', '')[:10] if memory.get('created_at') else '未知'
            
            response += f"{i}. **{text}**\n"
            response += f"   分类：{category} | 重要性：{importance:.2f} | 时间：{created}\n\n"
        
        if len(results) > 10:
            response += f"... 还有 {len(results) - 10} 条结果\n"
        
        return response
    
    def get_stats(self) -> str:
        """获取记忆统计"""
        if not self.memories:
            return "📭 暂无记忆"
        
        # 按分类统计
        categories = {}
        for m in self.memories:
            cat = m.get('category', '未分类')
            categories[cat] = categories.get(cat, 0) + 1
        
        # 按重要性统计
        high = sum(1 for m in self.memories if m.get('importance', 0) > 0.7)
        medium = sum(1 for m in self.memories if 0.3 <= m.get('importance', 0) <= 0.7)
        low = sum(1 for m in self.memories if m.get('importance', 0) < 0.3)
        
        # 时间统计
        recent_7d = 0
        recent_30d = 0
        for m in self.memories:
            created = m.get('created_at', '')
            if created:
                try:
                    memory_date = datetime.fromisoformat(created)
                    if datetime.now() - memory_date <= timedelta(days=7):
                        recent_7d += 1
                    if datetime.now() - memory_date <= timedelta(days=30):
                        recent_30d += 1
                except:
                    pass
        
        # 生成统计
        response = "📊 **记忆统计**\n\n"
        response += f"**总记忆数**: {len(self.memories)} 条\n\n"
        
        response += "**按重要性**:\n"
        response += f"  - 高重要性 (>0.7): {high} 条 ({high/len(self.memories)*100:.1f}%)\n"
        response += f"  - 中重要性 (0.3-0.7): {medium} 条 ({medium/len(self.memories)*100:.1f}%)\n"
        response += f"  - 低重要性 (<0.3): {low} 条 ({low/len(self.memories)*100:.1f}%)\n\n"
        
        response += "**按时间**:\n"
        response += f"  - 最近 7 天：{recent_7d} 条\n"
        response += f"  - 最近 30 天：{recent_30d} 条\n\n"
        
        response += "**按分类**:\n"
        for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True)[:10]:
            response += f"  - {cat}: {count} 条 ({count/len(self.memories)*100:.1f}%)\n"
        
        return response
    
    def export_memories(self, project_name: str = None) -> str:
        """导出记忆"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            if project_name:
                filename = f"/root/.openclaw/workspace/exports/{project_name}_{timestamp}.md"
                # 按项目过滤
                if project_name in ['天裂', '天裂世界观']:
                    memories_to_export = [m for m in self.memories 
                                        if m.get('category') in ['世界观', '角色', '剧情', '设定']]
                else:
                    memories_to_export = self.memories
            else:
                filename = f"/root/.openclaw/workspace/exports/all_memories_{timestamp}.md"
                memories_to_export = self.memories
            
            # 创建目录
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            
            # 导出为 Markdown
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f"# 记忆导出\n\n")
                f.write(f"**导出时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"**总条数**: {len(memories_to_export)}\n\n")
                f.write(f"---\n\n")
                
                for i, memory in enumerate(memories_to_export, 1):
                    text = memory.get('text', '')
                    category = memory.get('category', '未分类')
                    importance = memory.get('importance', 0.5)
                    tags = memory.get('tags', [])
                    created = memory.get('created_at', '')[:10] if memory.get('created_at') else '未知'
                    
                    f.write(f"## {i}. {text[:50]}...\n\n")
                    f.write(f"- **分类**: {category}\n")
                    f.write(f"- **重要性**: {importance:.2f}\n")
                    f.write(f"- **时间**: {created}\n")
                    if tags:
                        f.write(f"- **标签**: {', '.join(tags)}\n")
                    f.write(f"\n{text}\n\n")
                    f.write(f"---\n\n")
            
            return f"✅ 已导出 {len(memories_to_export)} 条记忆到：\n`{filename}`"
        
        except Exception as e:
            return f"❌ 导出失败：{e}"
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #搜索 [关键词]
        if command.startswith('#搜索') or command.startswith('#查找'):
            keywords = command.replace('#搜索', '').replace('#查找', '').strip()
            
            # 解析参数
            category = None
            days = None
            
            if ' 分类:' in keywords:
                parts = keywords.split(' 分类:')
                keywords = parts[0].strip()
                category = parts[1].split()[0].strip()
            
            if ' 最近' in keywords and '天' in keywords:
                import re
                match = re.search(r'最近 (\d+) 天', keywords)
                if match:
                    days = int(match.group(1))
                    keywords = keywords.replace(f'最近 {days} 天', '').strip()
            
            return self.search(keywords, category, days=days)
        
        # #记忆统计
        elif command == '#记忆统计':
            return self.get_stats()
        
        # #导出 [项目名]
        elif command.startswith('#导出'):
            project = command.replace('#导出', '').strip()
            return self.export_memories(project if project else None)
        
        # #导入 [文件名]
        elif command.startswith('#导入'):
            return "⚠️ 导入功能开发中，请使用手动导入"
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 advanced_search.py [命令]")
        print("示例：")
        print("  python3 advanced_search.py '#搜索 主角'")
        print("  python3 advanced_search.py '#记忆统计'")
        print("  python3 advanced_search.py '#导出 天裂'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    searcher = AdvancedSearch()
    result = searcher.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
