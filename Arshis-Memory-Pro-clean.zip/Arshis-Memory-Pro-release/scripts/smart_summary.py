#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能摘要功能

功能：
- 自动生成记忆摘要
- 自动关联相关记忆
- 自动打标签
- 自动分类
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Optional
from collections import Counter


class SmartSummary:
    """智能摘要"""
    
    def __init__(self, memory_path: str = None):
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        
        self.memory_path = memory_path
        self.memories = []
        self.load_memories()
    
    def load_memories(self):
        """加载记忆"""
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
        except:
            self.memories = []
    
    def save_memories(self):
        """保存记忆"""
        try:
            os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
            with open(self.memory_path, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"❌ 保存失败：{e}", file=sys.stderr)
    
    def generate_summary(self, text: str, max_length: int = 50) -> str:
        """
        生成摘要
        
        Args:
            text: 原始文本
            max_length: 最大长度
        """
        if len(text) <= max_length:
            return text
        
        # 简单摘要：取第一句
        sentences = text.split('。')
        summary = sentences[0]
        
        if len(summary) > max_length:
            summary = summary[:max_length] + '...'
        else:
            summary += '。'
        
        return summary
    
    def auto_categorize(self, text: str) -> str:
        """
        自动分类
        
        Args:
            text: 文本内容
        """
        text_lower = text.lower()
        
        # 分类关键词
        categories = {
            '世界观': {
                'keywords': ['世界观', '设定', '背景', '九重天', '浮空岛', '建木', '五裔', '种族'],
                'score': 0
            },
            '角色': {
                'keywords': ['角色', '人物', '主角', '性格', '名字', '艾伦', '背景故事'],
                'score': 0
            },
            '剧情': {
                'keywords': ['剧情', '故事', '情节', '章节', '主线', '支线', '任务'],
                'score': 0
            },
            '游戏设计': {
                'keywords': ['游戏', '玩法', '系统', '付费', '活动', '运营', '策划'],
                'score': 0
            },
            '数值': {
                'keywords': ['数值', '平衡', '公式', '计算', '概率', 'arpu', 'ltv'],
                'score': 0
            },
            'UI': {
                'keywords': ['ui', '界面', '交互', '设计', '布局', '视觉'],
                'score': 0
            },
            '美术': {
                'keywords': ['美术', '风格', '原画', '模型', '特效', '色彩'],
                'score': 0
            },
            '音效': {
                'keywords': ['音效', '音乐', '配音', 'bgm', '声音'],
                'score': 0
            }
        }
        
        # 计算每个分类的得分
        for category, data in categories.items():
            for keyword in data['keywords']:
                if keyword in text_lower:
                    data['score'] += 1
        
        # 返回得分最高的分类
        best_category = max(categories.items(), key=lambda x: x[1]['score'])
        
        if best_category[1]['score'] > 0:
            return best_category[0]
        else:
            return '其他'
    
    def auto_tag(self, text: str, max_tags: int = 10) -> List[str]:
        """
        自动打标签
        
        Args:
            text: 文本内容
            max_tags: 最大标签数
        """
        text_lower = text.lower()
        
        # 标签关键词
        tag_keywords = {
            'RPG': ['rpg', '角色扮演', '回合制', '即时制'],
            '二次元': ['二次元', '动漫', '日系', '卡通'],
            'SLG': ['slg', '策略', '战棋', '回合策略'],
            'MOBA': ['moba', '竞技', '推塔', '团战'],
            'FPS': ['fps', '射击', '第一人称', '枪战'],
            '模拟经营': ['模拟', '经营', '养成', '建造'],
            '开放世界': ['开放世界', '沙盒', '探索', '自由'],
            '抽卡': ['抽卡', 'gacha', '卡池', '保底'],
            '付费设计': ['付费', '内购', '氪金', '月卡', '通行证'],
            '世界观': ['世界观', '设定', '背景', '架构'],
            '角色设计': ['角色', '人设', '性格', '背景故事'],
            '剧情': ['剧情', '故事', '情节', '叙事'],
        }
        
        tags = []
        for tag, keywords in tag_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    tags.append(tag)
                    break
        
        # 限制标签数量
        return tags[:max_tags]
    
    def find_related(self, memory_id: str, limit: int = 5) -> List[Dict]:
        """
        查找相关记忆
        
        Args:
            memory_id: 记忆 ID
            limit: 返回数量
        """
        # 找到目标记忆
        target = None
        for m in self.memories:
            if m.get('id') == memory_id:
                target = m
                break
        
        if not target:
            return []
        
        # 计算相似度
        scored = []
        target_text = target.get('text', '').lower()
        target_tags = set(target.get('tags', []))
        target_category = target.get('category', '')
        
        for m in self.memories:
            if m.get('id') == memory_id:
                continue
            
            score = 0
            m_text = m.get('text', '').lower()
            m_tags = set(m.get('tags', []))
            m_category = m.get('category', '')
            
            # 相同分类
            if m_category == target_category:
                score += 10
            
            # 共享标签
            shared_tags = target_tags.intersection(m_tags)
            score += len(shared_tags) * 5
            
            # 文本相似度（简单关键词匹配）
            common_words = set(target_text.split()) & set(m_text.split())
            score += min(len(common_words), 10)
            
            if score > 0:
                scored.append((score, m))
        
        # 按得分排序
        scored.sort(key=lambda x: x[0], reverse=True)
        
        # 返回前 N 个
        return [m for score, m in scored[:limit]]
    
    def process_all_memories(self) -> str:
        """处理所有记忆，添加摘要/分类/标签"""
        if not self.memories:
            return "📭 暂无记忆"
        
        updated_count = 0
        
        for m in self.memories:
            text = m.get('text', '')
            
            # 自动摘要
            if 'summary' not in m:
                m['summary'] = self.generate_summary(text)
            
            # 自动分类
            if 'category' not in m or m.get('category') == '未分类':
                m['category'] = self.auto_categorize(text)
            
            # 自动标签
            if not m.get('tags'):
                m['tags'] = self.auto_tag(text)
            
            updated_count += 1
        
        self.save_memories()
        
        return f"✅ 已处理 {updated_count} 条记忆，添加摘要/分类/标签"
    
    def get_enhanced_memory(self, memory_id: str) -> str:
        """获取增强版记忆（含关联）"""
        # 找到记忆
        target = None
        for m in self.memories:
            if m.get('id') == memory_id:
                target = m
                break
        
        if not target:
            return "❌ 未找到记忆"
        
        # 查找关联
        related = self.find_related(memory_id)
        
        # 生成增强信息
        response = f"📝 **记忆详情**\n\n"
        response += f"**内容**: {target.get('text', '')}\n\n"
        response += f"**分类**: {target.get('category', '未分类')}\n"
        response += f"**标签**: {', '.join(target.get('tags', []))}\n"
        response += f"**重要性**: {target.get('importance', 0.5):.2f}\n\n"
        
        if related:
            response += f"**关联记忆** ({len(related)}条):\n"
            for i, r in enumerate(related[:5], 1):
                text = r.get('text', '')[:60]
                response += f"  {i}. {text}...\n"
        
        return response
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #智能处理
        if command == '#智能处理':
            return self.process_all_memories()
        
        # #查看增强 [记忆 ID]
        elif command.startswith('#查看增强'):
            memory_id = command.replace('#查看增强', '').strip()
            return self.get_enhanced_memory(memory_id)
        
        # #查找关联 [记忆 ID]
        elif command.startswith('#查找关联'):
            memory_id = command.replace('#查找关联', '').strip()
            related = self.find_related(memory_id)
            
            if not related:
                return "📭 未找到关联记忆"
            
            response = f"🔗 **关联记忆** ({len(related)}条):\n\n"
            for i, r in enumerate(related[:10], 1):
                text = r.get('text', '')[:80]
                response += f"{i}. {text}...\n"
            
            return response
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 smart_summary.py [命令]")
        print("示例：")
        print("  python3 smart_summary.py '#智能处理'")
        print("  python3 smart_summary.py '#查看增强 [ID]'")
        print("  python3 smart_summary.py '#查找关联 [ID]'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    summary = SmartSummary()
    result = summary.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
