#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆导入功能

支持：
- 从 Markdown 文件导入
- 从 JSON 文件导入
- 批量导入
- 自动分类和打标签
"""

import json
import os
import sys
import re
from datetime import datetime
from typing import List, Dict, Optional


class MemoryImporter:
    """记忆导入器"""
    
    def __init__(self, memory_path: str = None):
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        
        self.memory_path = memory_path
        self.memories = []
        self.load_memories()
    
    def load_memories(self):
        """加载现有记忆"""
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
        except:
            self.memories = []
    
    def save_memories(self):
        """保存记忆"""
        try:
            os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
            with open(self.memory_path, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"❌ 保存失败：{e}", file=sys.stderr)
    
    def import_from_markdown(self, filepath: str, category: str = None, 
                            auto_tag: bool = True) -> str:
        """
        从 Markdown 文件导入
        
        Args:
            filepath: Markdown 文件路径
            category: 默认分类
            auto_tag: 是否自动打标签
        """
        if not os.path.exists(filepath):
            return f"❌ 文件不存在：{filepath}"
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            return f"❌ 读取失败：{e}"
        
        # 解析 Markdown
        sections = self._parse_markdown(content)
        
        # 导入记忆
        imported_count = 0
        for section in sections:
            memory = {
                'id': self._generate_id(),
                'text': section['content'][:500],  # 限制长度
                'category': category or section.get('category', '未分类'),
                'importance': 0.5,  # 默认重要性
                'tags': [],
                'created_at': datetime.now().isoformat(),
                'source': f'import:{filepath}'
            }
            
            # 自动打标签
            if auto_tag:
                memory['tags'] = self._auto_tags(section['content'])
            
            self.memories.append(memory)
            imported_count += 1
        
        self.save_memories()
        
        return f"✅ 成功导入 {imported_count} 条记忆 from `{filepath}`"
    
    def import_from_json(self, filepath: str) -> str:
        """
        从 JSON 文件导入
        
        Args:
            filepath: JSON 文件路径
        """
        if not os.path.exists(filepath):
            return f"❌ 文件不存在：{filepath}"
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                imported_memories = json.load(f)
        except Exception as e:
            return f"❌ 读取失败：{e}"
        
        if not isinstance(imported_memories, list):
            return "❌ JSON 格式错误：应该是记忆列表"
        
        # 导入记忆
        imported_count = 0
        for m in imported_memories:
            if isinstance(m, dict) and 'text' in m:
                # 生成新 ID
                m['id'] = self._generate_id()
                m['imported_at'] = datetime.now().isoformat()
                m['source'] = f'import:{filepath}'
                
                self.memories.append(m)
                imported_count += 1
        
        self.save_memories()
        
        return f"✅ 成功导入 {imported_count} 条记忆 from `{filepath}`"
    
    def batch_import(self, directory: str, pattern: str = '*.md') -> str:
        """
        批量导入
        
        Args:
            directory: 目录路径
            pattern: 文件匹配模式
        """
        if not os.path.isdir(directory):
            return f"❌ 目录不存在：{directory}"
        
        import glob
        files = glob.glob(os.path.join(directory, pattern))
        
        if not files:
            return f"❌ 未找到匹配的文件：{pattern}"
        
        total_imported = 0
        
        for filepath in files:
            if filepath.endswith('.md'):
                result = self.import_from_markdown(filepath)
                if '成功导入' in result:
                    # 提取数量
                    match = re.search(r'导入 (\d+) 条', result)
                    if match:
                        total_imported += int(match.group(1))
            elif filepath.endswith('.json'):
                result = self.import_from_json(filepath)
                if '成功导入' in result:
                    match = re.search(r'导入 (\d+) 条', result)
                    if match:
                        total_imported += int(match.group(1))
        
        return f"✅ 批量导入完成：总计 {total_imported} 条记忆 from {len(files)} 个文件"
    
    def _parse_markdown(self, content: str) -> List[Dict]:
        """解析 Markdown 内容"""
        sections = []
        
        # 按标题分割
        current_section = {'content': '', 'category': '未分类'}
        
        lines = content.split('\n')
        for line in lines:
            # 检测标题
            if line.startswith('# '):
                # 保存之前的 section
                if current_section['content'].strip():
                    sections.append(current_section.copy())
                
                # 新 section
                title = line.replace('# ', '').strip()
                current_section = {
                    'content': title + '\n',
                    'category': self._infer_category(title)
                }
            elif line.startswith('## '):
                # 子标题
                if current_section['content'].strip():
                    sections.append(current_section.copy())
                
                subtitle = line.replace('## ', '').strip()
                current_section = {
                    'content': subtitle + '\n',
                    'category': self._infer_category(subtitle)
                }
            else:
                # 普通内容
                current_section['content'] += line + '\n'
        
        # 保存最后一个 section
        if current_section['content'].strip():
            sections.append(current_section)
        
        return sections
    
    def _infer_category(self, text: str) -> str:
        """从文本推断分类"""
        text_lower = text.lower()
        
        category_keywords = {
            '世界观': ['世界观', '设定', '背景', '九重天', '浮空岛'],
            '角色': ['角色', '人物', '主角', '艾伦', '性格'],
            '剧情': ['剧情', '故事', '情节', '章节'],
            '游戏设计': ['游戏', '玩法', '系统', '付费', '活动'],
            '数值': ['数值', '平衡', '公式', '计算'],
            'UI': ['UI', '界面', '交互', '设计'],
        }
        
        for category, keywords in category_keywords.items():
            if any(kw in text_lower for kw in keywords):
                return category
        
        return '未分类'
    
    def _auto_tags(self, text: str) -> List[str]:
        """自动打标签"""
        tags = []
        
        # 提取关键词作为标签
        keywords = {
            'RPG': ['RPG', '角色扮演'],
            '二次元': ['二次元', '动漫'],
            'SLG': ['SLG', '策略'],
            'MOBA': ['MOBA', '竞技'],
            'FPS': ['FPS', '射击'],
        }
        
        text_lower = text.lower()
        for tag, words in keywords.items():
            if any(word in text_lower for word in words):
                tags.append(tag)
        
        # 限制标签数量
        return tags[:10]
    
    def _generate_id(self) -> str:
        """生成唯一 ID"""
        import hashlib
        import time
        content = f"{time.time()}{len(self.memories)}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #导入 [文件路径]
        if command.startswith('#导入'):
            filepath = command.replace('#导入', '').strip()
            if not filepath:
                return "❌ 用法：#导入 [文件路径]\n例：#导入 /path/to/file.md"
            
            if filepath.endswith('.md'):
                return self.import_from_markdown(filepath)
            elif filepath.endswith('.json'):
                return self.import_from_json(filepath)
            else:
                return "❌ 不支持的文件格式，请使用 .md 或 .json"
        
        # #批量导入 [目录]
        elif command.startswith('#批量导入'):
            directory = command.replace('#批量导入', '').strip()
            if not directory:
                return "❌ 用法：#批量导入 [目录]\n例：#批量导入 /path/to/docs"
            
            return self.batch_import(directory)
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 memory_import.py [命令]")
        print("示例：")
        print("  python3 memory_import.py '#导入 /path/to/file.md'")
        print("  python3 memory_import.py '#批量导入 /path/to/docs'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    importer = MemoryImporter()
    result = importer.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
