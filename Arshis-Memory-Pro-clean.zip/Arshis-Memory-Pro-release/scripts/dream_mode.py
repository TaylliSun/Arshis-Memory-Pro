#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
梦境模式

功能：
- #梦境 [内容] - 记录梦境/灵感
- #回放今天 - 回顾当天对话
- #晨间摘要 - 生成醒来后摘要
- #孵化 [问题] - 设置创意孵化问题
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict


class DreamMode:
    """梦境模式"""
    
    def __init__(self, memory_path: str = None, dream_path: str = None):
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        if dream_path is None:
            dream_path = '/root/.openclaw/data/memory-custom/dreams.json'
        
        self.memory_path = memory_path
        self.dream_path = dream_path
        self.memories = []
        self.dreams = []
        self.load_data()
    
    def load_data(self):
        """加载数据"""
        # 加载记忆
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
        except:
            self.memories = []
        
        # 加载梦境
        try:
            if os.path.exists(self.dream_path):
                with open(self.dream_path, 'r', encoding='utf-8') as f:
                    self.dreams = json.load(f)
            else:
                self.dreams = []
        except:
            self.dreams = []
    
    def save_dreams(self):
        """保存梦境"""
        try:
            os.makedirs(os.path.dirname(self.dream_path), exist_ok=True)
            with open(self.dream_path, 'w', encoding='utf-8') as f:
                json.dump(self.dreams, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"❌ 保存失败：{e}", file=sys.stderr)
    
    def record_dream(self, content: str) -> str:
        """记录梦境"""
        dream = {
            'id': len(self.dreams) + 1,
            'content': content,
            'created_at': datetime.now().isoformat(),
            'category': '梦境/灵感',
            'tags': ['梦境', '灵感', '创意']
        }
        
        self.dreams.append(dream)
        self.save_dreams()
        
        return f"✅ 已记录梦境/灵感：\n{content[:50]}...\n\n💡 梦境已保存到创意分类，可用于创作素材"
    
    def review_today(self) -> str:
        """回放今天"""
        today = datetime.now().date()
        today_memories = []
        
        for m in self.memories:
            created = m.get('created_at', '')
            if created:
                try:
                    memory_date = datetime.fromisoformat(created).date()
                    if memory_date == today:
                        today_memories.append(m)
                except:
                    pass
        
        if not today_memories:
            return "📭 今天还没有记忆记录"
        
        response = f"📝 **今日摘要** ({today})\n\n"
        response += f"**总计**: {len(today_memories)} 条记忆\n\n"
        
        # 按分类汇总
        categories = {}
        for m in today_memories:
            cat = m.get('category', '未分类')
            categories[cat] = categories.get(cat, 0) + 1
        
        response += "**分类统计**:\n"
        for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            response += f"  - {cat}: {count} 条\n"
        
        response += "\n**重要记忆**:\n"
        important = [m for m in today_memories if m.get('importance', 0) > 0.7][:5]
        
        for i, m in enumerate(important, 1):
            text = m.get('text', '')[:80]
            if len(m.get('text', '')) > 80:
                text += '...'
            response += f"{i}. {text}\n"
        
        response += "\n💡 晚安！明天醒来可以使用 #晨间摘要 回顾"
        
        return response
    
    def morning_brief(self) -> str:
        """晨间摘要"""
        today = datetime.now().date()
        yesterday = today - timedelta(days=1)
        
        # 昨天的记忆
        yesterday_memories = []
        for m in self.memories:
            created = m.get('created_at', '')
            if created:
                try:
                    memory_date = datetime.fromisoformat(created).date()
                    if memory_date == yesterday:
                        yesterday_memories.append(m)
                except:
                    pass
        
        # 昨天的梦境
        yesterday_dreams = []
        for d in self.dreams:
            created = d.get('created_at', '')
            if created:
                try:
                    dream_date = datetime.fromisoformat(created).date()
                    if dream_date == yesterday:
                        yesterday_dreams.append(d)
                except:
                    pass
        
        response = f"🌅 **晨间摘要** ({today})\n\n"
        
        # 昨天回顾
        if yesterday_memories:
            response += f"**昨天回顾**:\n"
            response += f"  - 新增记忆：{len(yesterday_memories)} 条\n"
            
            # 重要记忆
            important = [m for m in yesterday_memories if m.get('importance', 0) > 0.7][:3]
            if important:
                response += f"\n  **重要记忆**:\n"
                for m in important:
                    text = m.get('text', '')[:60]
                    response += f"  • {text}\n"
        
        # 梦境回顾
        if yesterday_dreams:
            response += f"\n**梦境记录**:\n"
            for d in yesterday_dreams:
                content = d.get('content', '')[:60]
                response += f"  • {content}\n"
        
        # 创意孵化
        incubations = self.get_active_incubations()
        if incubations:
            response += f"\n**创意孵化**:\n"
            for inc in incubations:
                response += f"  • {inc['question']}\n"
            response += f"\n💡 今天继续思考这些问题，可能会有新灵感！\n"
        
        if not yesterday_memories and not yesterday_dreams:
            response += "📭 昨天没有记录\n"
        
        response += f"\n✨ 新的一天开始了！有什么要继续的吗？"
        
        return response
    
    def set_incubation(self, question: str) -> str:
        """设置创意孵化"""
        incubation = {
            'id': len([i for i in self.dreams if i.get('type') == 'incubation']) + 1,
            'type': 'incubation',
            'question': question,
            'created_at': datetime.now().isoformat(),
            'status': 'active'
        }
        
        self.dreams.append(incubation)
        self.save_dreams()
        
        return f"✅ 已设置创意孵化问题：\n{question}\n\n🔮 睡前思考这个问题，明天可能会有新灵感！"
    
    def get_active_incubations(self) -> List[Dict]:
        """获取活跃的孵化问题"""
        return [i for i in self.dreams 
                if i.get('type') == 'incubation' and i.get('status') == 'active']
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #梦境 [内容]
        if command.startswith('#梦境'):
            content = command.replace('#梦境', '').strip()
            if content:
                return self.record_dream(content)
            return "❌ 请提供梦境内容，例如：#梦境 梦到主角在天空战斗"
        
        # #回放今天
        elif command == '#回放今天':
            return self.review_today()
        
        # #晨间摘要
        elif command == '#晨间摘要':
            return self.morning_brief()
        
        # #孵化 [问题]
        elif command.startswith('#孵化'):
            question = command.replace('#孵化', '').strip()
            if question:
                return self.set_incubation(question)
            return "❌ 请提供问题，例如：#孵化 如何设计有趣的战斗系统"
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 dream_mode.py [命令]")
        print("示例：")
        print("  python3 dream_mode.py '#梦境 梦到主角飞行'")
        print("  python3 dream_mode.py '#回放今天'")
        print("  python3 dream_mode.py '#晨间摘要'")
        print("  python3 dream_mode.py '#孵化 如何设计战斗系统'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    dream = DreamMode()
    result = dream.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
