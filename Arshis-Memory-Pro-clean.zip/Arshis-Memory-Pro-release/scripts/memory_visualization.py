#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆可视化功能

功能：
- #记忆图谱 - 生成记忆关系图
- #标签云 - 显示热门标签
- #增长曲线 - 显示记忆增长趋势
- #分类分布 - 显示分类分布图
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Set
from collections import Counter


class MemoryVisualization:
    """记忆可视化"""
    
    def __init__(self, memory_path: str = None):
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        
        self.memory_path = memory_path
        self.memories = []
        self.load_memories()
    
    def load_memories(self):
        """加载记忆"""
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
        except:
            self.memories = []
    
    def get_tag_cloud(self, limit: int = 20) -> str:
        """生成标签云"""
        # 统计标签频率
        tag_counter = Counter()
        for m in self.memories:
            tags = m.get('tags', [])
            for tag in tags:
                tag_counter[tag] += 1
        
        if not tag_counter:
            return "📭 暂无标签"
        
        # 生成标签云（文本版）
        response = "🏷️ **热门标签云**\n\n"
        
        top_tags = tag_counter.most_common(limit)
        max_count = top_tags[0][1] if top_tags else 1
        
        for tag, count in top_tags:
            # 计算大小（1-5 级）
            size = int((count / max_count) * 5) + 1
            stars = "⭐" * size
            response += f"{stars} **{tag}** ({count}条)\n"
        
        return response
    
    def get_category_distribution(self) -> str:
        """分类分布"""
        if not self.memories:
            return "📭 暂无记忆"
        
        # 统计分类
        categories = Counter(m.get('category', '未分类') for m in self.memories)
        
        response = "📂 **分类分布**\n\n"
        
        # 生成文本柱状图
        max_count = max(categories.values()) if categories else 1
        bar_width = 30
        
        for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            bar_length = int((count / max_count) * bar_width)
            bar = "█" * bar_length + "░" * (bar_width - bar_length)
            percentage = (count / len(self.memories)) * 100
            
            response += f"{cat:10} |{bar}| {count:4}条 ({percentage:5.1f}%)\n"
        
        return response
    
    def get_growth_curve(self, days: int = 30) -> str:
        """增长曲线"""
        if not self.memories:
            return "📭 暂无记忆"
        
        # 统计每天的新增记忆
        today = datetime.now().date()
        daily_counts = {}
        
        for i in range(days):
            date = today - timedelta(days=i)
            daily_counts[date] = 0
        
        for m in self.memories:
            created = m.get('created_at', '')
            if created:
                try:
                    memory_date = datetime.fromisoformat(created).date()
                    if memory_date in daily_counts:
                        daily_counts[memory_date] += 1
                except:
                    pass
        
        # 生成文本曲线图
        response = f"📈 **记忆增长曲线**（最近{days}天）\n\n"
        
        max_count = max(daily_counts.values()) if daily_counts else 1
        chart_height = 10
        
        for i in range(days - 1, -1, -1):
            date = today - timedelta(days=i)
            count = daily_counts.get(date, 0)
            
            # 日期标签（每周显示一次）
            date_label = date.strftime("%m-%d")
            if i % 7 != 0:
                date_label = " " * 5
            
            # 柱状图
            if count > 0:
                bar_height = int((count / max_count) * chart_height)
                bar = "▃▄▅▆▇█"[min(bar_height, 5)] * min(count, 6)
                response += f"{date_label} | {bar} ({count})\n"
            else:
                response += f"{date_label} |\n"
        
        response += f"\n**总计**: {sum(daily_counts.values())}条（{days}天）\n"
        
        return response
    
    def get_memory_graph(self, keyword: str = None, depth: int = 2) -> str:
        """生成记忆关系图"""
        if not self.memories:
            return "📭 暂无记忆"
        
        # 找到中心记忆
        if keyword:
            center_memories = [m for m in self.memories 
                             if keyword.lower() in m.get('text', '').lower()]
        else:
            # 选择最重要的记忆作为中心
            center_memories = sorted(self.memories, 
                                    key=lambda x: x.get('importance', 0), 
                                    reverse=True)[:5]
        
        if not center_memories:
            return "❌ 未找到相关记忆"
        
        response = f"🕸️ **记忆关系图**"
        if keyword:
            response += f"（关键词：{keyword}）"
        response += f"\n\n"
        
        # 生成关系图（文本版）
        for center in center_memories[:3]:
            center_text = center.get('text', '')[:50]
            center_cat = center.get('category', '未分类')
            center_tags = center.get('tags', [])
            
            response += f"📍 **{center_text}**\n"
            response += f"   分类：{center_cat}\n"
            
            if center_tags:
                response += f"   标签：{', '.join(center_tags)}\n"
            
            # 查找相关记忆（共享标签或分类）
            related = []
            for m in self.memories:
                if m == center:
                    continue
                
                # 相同分类
                if m.get('category') == center_cat:
                    related.append((m, '分类'))
                    continue
                
                # 共享标签
                center_tag_set = set(center_tags)
                m_tags = m.get('tags', [])
                shared_tags = center_tag_set.intersection(set(m_tags))
                if shared_tags:
                    related.append((m, f"标签:{','.join(shared_tags)}"))
            
            # 显示相关记忆
            if related:
                response += f"   **关联**:\n"
                for rel, reason in related[:5]:
                    rel_text = rel.get('text', '')[:40]
                    response += f"     → [{reason}] {rel_text}...\n"
            
            response += f"\n"
        
        return response
    
    def get_importance_distribution(self) -> str:
        """重要性分布"""
        if not self.memories:
            return "📭 暂无记忆"
        
        # 分组统计
        groups = {
            '极高 (0.9-1.0)': 0,
            '高 (0.7-0.9)': 0,
            '中高 (0.5-0.7)': 0,
            '中 (0.3-0.5)': 0,
            '低 (0.1-0.3)': 0,
            '极低 (0-0.1)': 0
        }
        
        for m in self.memories:
            imp = m.get('importance', 0.5)
            if imp >= 0.9:
                groups['极高 (0.9-1.0)'] += 1
            elif imp >= 0.7:
                groups['高 (0.7-0.9)'] += 1
            elif imp >= 0.5:
                groups['中高 (0.5-0.7)'] += 1
            elif imp >= 0.3:
                groups['中 (0.3-0.5)'] += 1
            elif imp >= 0.1:
                groups['低 (0.1-0.3)'] += 1
            else:
                groups['极低 (0-0.1)'] += 1
        
        response = "📊 **重要性分布**\n\n"
        
        max_count = max(groups.values()) if groups else 1
        bar_width = 30
        
        for group, count in groups.items():
            bar_length = int((count / max_count) * bar_width)
            bar = "█" * bar_length + "░" * (bar_width - bar_length)
            percentage = (count / len(self.memories)) * 100
            
            response += f"{group:15} |{bar}| {count:4}条 ({percentage:5.1f}%)\n"
        
        return response
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #标签云
        if command == '#标签云':
            return self.get_tag_cloud()
        
        # #分类分布
        elif command == '#分类分布':
            return self.get_category_distribution()
        
        # #增长曲线 [天数]
        elif command.startswith('#增长曲线'):
            days = 30
            if command.startswith('#增长曲线 '):
                try:
                    days = int(command.replace('#增长曲线 ', '').strip())
                except:
                    pass
            return self.get_growth_curve(days)
        
        # #记忆图谱 [关键词]
        elif command.startswith('#记忆图谱'):
            keyword = None
            if command.startswith('#记忆图谱 '):
                keyword = command.replace('#记忆图谱 ', '').strip()
            return self.get_memory_graph(keyword)
        
        # #重要性分布
        elif command == '#重要性分布':
            return self.get_importance_distribution()
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 memory_visualization.py [命令]")
        print("示例：")
        print("  python3 memory_visualization.py '#标签云'")
        print("  python3 memory_visualization.py '#分类分布'")
        print("  python3 memory_visualization.py '#增长曲线 30'")
        print("  python3 memory_visualization.py '#记忆图谱 主角'")
        print("  python3 memory_visualization.py '#重要性分布'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    viz = MemoryVisualization()
    result = viz.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
