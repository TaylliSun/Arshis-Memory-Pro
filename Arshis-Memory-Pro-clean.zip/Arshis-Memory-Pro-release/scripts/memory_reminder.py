#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆提醒功能

功能：
- #提醒 每周回顾 - 设置定期提醒
- #查看提醒 - 查看所有提醒
- #重要记忆提醒 - 提醒重要记忆
- #项目进度提醒 - 项目进度提醒
"""

import json
import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Optional


class MemoryReminder:
    """记忆提醒"""
    
    def __init__(self, reminder_path: str = None, memory_path: str = None):
        if reminder_path is None:
            reminder_path = '/root/.openclaw/data/memory-custom/reminders.json'
        if memory_path is None:
            memory_path = '/root/.openclaw/data/memory-custom/memories.json'
        
        self.reminder_path = reminder_path
        self.memory_path = memory_path
        self.reminders = []
        self.memories = []
        self.load_data()
    
    def load_data(self):
        """加载数据"""
        # 加载提醒
        try:
            if os.path.exists(self.reminder_path):
                with open(self.reminder_path, 'r', encoding='utf-8') as f:
                    self.reminders = json.load(f)
            else:
                self.reminders = []
        except:
            self.reminders = []
        
        # 加载记忆
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
        except:
            self.memories = []
    
    def save_reminders(self):
        """保存提醒"""
        try:
            os.makedirs(os.path.dirname(self.reminder_path), exist_ok=True)
            with open(self.reminder_path, 'w', encoding='utf-8') as f:
                json.dump(self.reminders, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"❌ 保存失败：{e}", file=sys.stderr)
    
    def set_reminder(self, reminder_type: str, target: str = None, 
                     frequency: str = 'weekly', time: str = '09:00') -> str:
        """
        设置提醒
        
        Args:
            reminder_type: 提醒类型 (weekly_review/important/project)
            target: 目标（项目名/分类名）
            frequency: 频率 (daily/weekly/monthly)
            time: 时间 (HH:MM)
        """
        reminder = {
            'id': len(self.reminders) + 1,
            'type': reminder_type,
            'target': target,
            'frequency': frequency,
            'time': time,
            'created_at': datetime.now().isoformat(),
            'last_triggered': None,
            'status': 'active'
        }
        
        self.reminders.append(reminder)
        self.save_reminders()
        
        # 生成友好提示
        type_names = {
            'weekly_review': '每周回顾',
            'important': '重要记忆提醒',
            'project': '项目进度提醒'
        }
        
        freq_names = {
            'daily': '每天',
            'weekly': '每周',
            'monthly': '每月'
        }
        
        response = f"✅ 已设置提醒：\n"
        response += f"  类型：{type_names.get(reminder_type, reminder_type)}\n"
        if target:
            response += f"  目标：{target}\n"
        response += f"  频率：{freq_names.get(frequency, frequency)}\n"
        response += f"  时间：{time}\n"
        response += f"\n⏰ 到时系统会提醒你！"
        
        return response
    
    def list_reminders(self) -> str:
        """查看所有提醒"""
        if not self.reminders:
            return "📭 暂无提醒"
        
        response = "⏰ **当前提醒**\n\n"
        
        type_names = {
            'weekly_review': '每周回顾',
            'important': '重要记忆',
            'project': '项目进度'
        }
        
        freq_names = {
            'daily': '每天',
            'weekly': '每周',
            'monthly': '每月'
        }
        
        active = [r for r in self.reminders if r.get('status') == 'active']
        inactive = [r for r in self.reminders if r.get('status') != 'active']
        
        if active:
            response += "**活跃提醒**:\n"
            for r in active:
                response += f"\n{r['id']}. {type_names.get(r['type'], r['type'])}\n"
                if r.get('target'):
                    response += f"   目标：{r['target']}\n"
                response += f"   频率：{freq_names.get(r['frequency'], r['frequency'])}\n"
                response += f"   时间：{r['time']}\n"
        
        if inactive:
            response += f"\n**已禁用提醒**: {len(inactive)}个\n"
        
        return response
    
    def get_important_reminder(self) -> str:
        """重要记忆提醒"""
        # 查找高重要性记忆
        important = [m for m in self.memories if m.get('importance', 0) > 0.8]
        
        if not important:
            return "📭 暂无高重要性记忆"
        
        # 按时间排序
        important.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        response = "💡 **重要记忆提醒**\n\n"
        response += f"当前有 {len(important)} 条高重要性记忆\n\n"
        
        response += "**最近的重要记忆**:\n"
        for m in important[:10]:
            text = m.get('text', '')[:80]
            if len(m.get('text', '')) > 80:
                text += '...'
            created = m.get('created_at', '')[:10] if m.get('created_at') else '未知'
            response += f"• {text}\n"
            response += f"  ({created})\n\n"
        
        response += "💡 建议定期回顾这些重要记忆！"
        
        return response
    
    def get_project_reminder(self, project_name: str = None) -> str:
        """项目进度提醒"""
        if not project_name:
            # 显示所有项目
            projects = {}
            for m in self.memories:
                cat = m.get('category', '未分类')
                if cat in ['世界观', '角色', '剧情', '设定', '游戏设计']:
                    projects[cat] = projects.get(cat, 0) + 1
            
            response = "📊 **项目进度**\n\n"
            for proj, count in sorted(projects.items(), key=lambda x: x[1], reverse=True):
                response += f"**{proj}**: {count}条记忆\n"
            
            return response
        
        # 特定项目
        project_memories = [m for m in self.memories 
                          if m.get('category') == project_name or 
                          project_name in m.get('text', '')]
        
        if not project_memories:
            return f"📭 未找到项目：{project_name}"
        
        # 统计
        recent_7d = 0
        recent_30d = 0
        
        for m in project_memories:
            created = m.get('created_at', '')
            if created:
                try:
                    memory_date = datetime.fromisoformat(created)
                    if datetime.now() - memory_date <= timedelta(days=7):
                        recent_7d += 1
                    if datetime.now() - memory_date <= timedelta(days=30):
                        recent_30d += 1
                except:
                    pass
        
        response = f"📊 **{project_name} 进度**\n\n"
        response += f"**总记忆数**: {len(project_memories)}条\n"
        response += f"**最近 7 天**: {recent_7d}条\n"
        response += f"**最近 30 天**: {recent_30d}条\n\n"
        
        # 分类统计
        categories = {}
        for m in project_memories:
            cat = m.get('category', '未分类')
            categories[cat] = categories.get(cat, 0) + 1
        
        response += "**分类分布**:\n"
        for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            response += f"  {cat}: {count}条\n"
        
        return response
    
    def delete_reminder(self, reminder_id: int) -> str:
        """删除提醒"""
        for r in self.reminders:
            if r['id'] == reminder_id:
                r['status'] = 'deleted'
                self.save_reminders()
                return f"✅ 已删除提醒 #{reminder_id}"
        
        return f"❌ 未找到提醒 #{reminder_id}"
    
    def process_command(self, command: str) -> str:
        """处理命令"""
        command = command.strip()
        
        # #提醒 [类型] [频率]
        if command.startswith('#提醒'):
            parts = command.replace('#提醒', '').strip().split()
            
            if not parts:
                return "❌ 用法：#提醒 [每周回顾/重要记忆/项目进度] [频率]\n例：#提醒 每周回顾 weekly"
            
            reminder_type = parts[0]
            frequency = parts[1] if len(parts) > 1 else 'weekly'
            
            # 映射类型
            type_map = {
                '每周回顾': 'weekly_review',
                '重要记忆': 'important',
                '项目进度': 'project'
            }
            
            actual_type = type_map.get(reminder_type, reminder_type)
            target = None
            
            if actual_type == 'project' and len(parts) > 2:
                target = parts[2]
            
            return self.set_reminder(actual_type, target, frequency)
        
        # #查看提醒
        elif command == '#查看提醒':
            return self.list_reminders()
        
        # #重要记忆提醒
        elif command == '#重要记忆提醒':
            return self.get_important_reminder()
        
        # #项目进度 [项目名]
        elif command.startswith('#项目进度'):
            project = command.replace('#项目进度', '').strip()
            return self.get_project_reminder(project if project else None)
        
        # #删除提醒 [ID]
        elif command.startswith('#删除提醒'):
            try:
                reminder_id = int(command.replace('#删除提醒', '').strip())
                return self.delete_reminder(reminder_id)
            except:
                return "❌ 用法：#删除提醒 [ID]"
        
        return None


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python3 memory_reminder.py [命令]")
        print("示例：")
        print("  python3 memory_reminder.py '#提醒 每周回顾 weekly'")
        print("  python3 memory_reminder.py '#查看提醒'")
        print("  python3 memory_reminder.py '#重要记忆提醒'")
        print("  python3 memory_reminder.py '#项目进度 天裂'")
        sys.exit(1)
    
    command = ' '.join(sys.argv[1:])
    reminder = MemoryReminder()
    result = reminder.process_command(command)
    
    if result:
        print(result)


if __name__ == "__main__":
    main()
